
import 'package:flutter/material.dart';

class MonetTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final IconData? icon;

  // 【修复】改为可空 int，允许传 null 实现自适应高度
  final int? maxLines;
  final int minLines;

  final bool autoFocus;
  final TextInputType? keyboardType;
  final Function(String)? onChanged;

  const MonetTextField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.icon,
    this.maxLines = 1, // 默认为 1
    this.minLines = 1,
    this.autoFocus = false,
    this.keyboardType,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return TextField(
      controller: controller,
      maxLines: maxLines,
      minLines: minLines,
      autofocus: autoFocus,
      keyboardType: keyboardType,
      style: const TextStyle(fontSize: 16),
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: icon != null ? Icon(icon, size: 20) : null,
        filled: true,
        fillColor: theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
        border: _buildBorder(),
        enabledBorder: _buildBorder(color: Colors.transparent),
        focusedBorder: _buildBorder(color: theme.colorScheme.primary, width: 2),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        isDense: true,
      ),
    );
  }

  OutlineInputBorder _buildBorder({Color color = Colors.transparent, double width = 0.0}) {
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide(color: color, width: width),
    );
  }
}