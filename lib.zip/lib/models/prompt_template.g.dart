// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'prompt_template.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetPromptTemplateCollection on Isar {
  IsarCollection<PromptTemplate> get promptTemplates => this.collection();
}

const PromptTemplateSchema = CollectionSchema(
  name: r'PromptTemplate',
  id: 6514867627799515997,
  properties: {
    r'baseSystemPrompt': PropertySchema(
      id: 0,
      name: r'baseSystemPrompt',
      type: IsarType.string,
    ),
    r'formatConstraint': PropertySchema(
      id: 1,
      name: r'formatConstraint',
      type: IsarType.string,
    ),
    r'fullOverride': PropertySchema(
      id: 2,
      name: r'fullOverride',
      type: IsarType.string,
    ),
    r'isAdvancedMode': PropertySchema(
      id: 3,
      name: r'isAdvancedMode',
      type: IsarType.bool,
    ),
    r'label': PropertySchema(
      id: 4,
      name: r'label',
      type: IsarType.string,
    ),
    r'sceneCode': PropertySchema(
      id: 5,
      name: r'sceneCode',
      type: IsarType.string,
    ),
    r'updatedAt': PropertySchema(
      id: 6,
      name: r'updatedAt',
      type: IsarType.dateTime,
    ),
    r'userCustomPreference': PropertySchema(
      id: 7,
      name: r'userCustomPreference',
      type: IsarType.string,
    )
  },
  estimateSize: _promptTemplateEstimateSize,
  serialize: _promptTemplateSerialize,
  deserialize: _promptTemplateDeserialize,
  deserializeProp: _promptTemplateDeserializeProp,
  idName: r'id',
  indexes: {
    r'sceneCode': IndexSchema(
      id: 8000798236563267426,
      name: r'sceneCode',
      unique: true,
      replace: true,
      properties: [
        IndexPropertySchema(
          name: r'sceneCode',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _promptTemplateGetId,
  getLinks: _promptTemplateGetLinks,
  attach: _promptTemplateAttach,
  version: '3.1.0+1',
);

int _promptTemplateEstimateSize(
  PromptTemplate object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.baseSystemPrompt;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.formatConstraint;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.fullOverride;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  bytesCount += 3 + object.label.length * 3;
  bytesCount += 3 + object.sceneCode.length * 3;
  {
    final value = object.userCustomPreference;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  return bytesCount;
}

void _promptTemplateSerialize(
  PromptTemplate object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeString(offsets[0], object.baseSystemPrompt);
  writer.writeString(offsets[1], object.formatConstraint);
  writer.writeString(offsets[2], object.fullOverride);
  writer.writeBool(offsets[3], object.isAdvancedMode);
  writer.writeString(offsets[4], object.label);
  writer.writeString(offsets[5], object.sceneCode);
  writer.writeDateTime(offsets[6], object.updatedAt);
  writer.writeString(offsets[7], object.userCustomPreference);
}

PromptTemplate _promptTemplateDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = PromptTemplate();
  object.baseSystemPrompt = reader.readStringOrNull(offsets[0]);
  object.formatConstraint = reader.readStringOrNull(offsets[1]);
  object.fullOverride = reader.readStringOrNull(offsets[2]);
  object.id = id;
  object.isAdvancedMode = reader.readBool(offsets[3]);
  object.label = reader.readString(offsets[4]);
  object.sceneCode = reader.readString(offsets[5]);
  object.updatedAt = reader.readDateTime(offsets[6]);
  object.userCustomPreference = reader.readStringOrNull(offsets[7]);
  return object;
}

P _promptTemplateDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readStringOrNull(offset)) as P;
    case 1:
      return (reader.readStringOrNull(offset)) as P;
    case 2:
      return (reader.readStringOrNull(offset)) as P;
    case 3:
      return (reader.readBool(offset)) as P;
    case 4:
      return (reader.readString(offset)) as P;
    case 5:
      return (reader.readString(offset)) as P;
    case 6:
      return (reader.readDateTime(offset)) as P;
    case 7:
      return (reader.readStringOrNull(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _promptTemplateGetId(PromptTemplate object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _promptTemplateGetLinks(PromptTemplate object) {
  return [];
}

void _promptTemplateAttach(
    IsarCollection<dynamic> col, Id id, PromptTemplate object) {
  object.id = id;
}

extension PromptTemplateByIndex on IsarCollection<PromptTemplate> {
  Future<PromptTemplate?> getBySceneCode(String sceneCode) {
    return getByIndex(r'sceneCode', [sceneCode]);
  }

  PromptTemplate? getBySceneCodeSync(String sceneCode) {
    return getByIndexSync(r'sceneCode', [sceneCode]);
  }

  Future<bool> deleteBySceneCode(String sceneCode) {
    return deleteByIndex(r'sceneCode', [sceneCode]);
  }

  bool deleteBySceneCodeSync(String sceneCode) {
    return deleteByIndexSync(r'sceneCode', [sceneCode]);
  }

  Future<List<PromptTemplate?>> getAllBySceneCode(
      List<String> sceneCodeValues) {
    final values = sceneCodeValues.map((e) => [e]).toList();
    return getAllByIndex(r'sceneCode', values);
  }

  List<PromptTemplate?> getAllBySceneCodeSync(List<String> sceneCodeValues) {
    final values = sceneCodeValues.map((e) => [e]).toList();
    return getAllByIndexSync(r'sceneCode', values);
  }

  Future<int> deleteAllBySceneCode(List<String> sceneCodeValues) {
    final values = sceneCodeValues.map((e) => [e]).toList();
    return deleteAllByIndex(r'sceneCode', values);
  }

  int deleteAllBySceneCodeSync(List<String> sceneCodeValues) {
    final values = sceneCodeValues.map((e) => [e]).toList();
    return deleteAllByIndexSync(r'sceneCode', values);
  }

  Future<Id> putBySceneCode(PromptTemplate object) {
    return putByIndex(r'sceneCode', object);
  }

  Id putBySceneCodeSync(PromptTemplate object, {bool saveLinks = true}) {
    return putByIndexSync(r'sceneCode', object, saveLinks: saveLinks);
  }

  Future<List<Id>> putAllBySceneCode(List<PromptTemplate> objects) {
    return putAllByIndex(r'sceneCode', objects);
  }

  List<Id> putAllBySceneCodeSync(List<PromptTemplate> objects,
      {bool saveLinks = true}) {
    return putAllByIndexSync(r'sceneCode', objects, saveLinks: saveLinks);
  }
}

extension PromptTemplateQueryWhereSort
    on QueryBuilder<PromptTemplate, PromptTemplate, QWhere> {
  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }
}

extension PromptTemplateQueryWhere
    on QueryBuilder<PromptTemplate, PromptTemplate, QWhereClause> {
  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause> idEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause> idNotEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause> idGreaterThan(
      Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause> idLessThan(
      Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause>
      sceneCodeEqualTo(String sceneCode) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'sceneCode',
        value: [sceneCode],
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterWhereClause>
      sceneCodeNotEqualTo(String sceneCode) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sceneCode',
              lower: [],
              upper: [sceneCode],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sceneCode',
              lower: [sceneCode],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sceneCode',
              lower: [sceneCode],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sceneCode',
              lower: [],
              upper: [sceneCode],
              includeUpper: false,
            ));
      }
    });
  }
}

extension PromptTemplateQueryFilter
    on QueryBuilder<PromptTemplate, PromptTemplate, QFilterCondition> {
  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'baseSystemPrompt',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'baseSystemPrompt',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'baseSystemPrompt',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'baseSystemPrompt',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'baseSystemPrompt',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'baseSystemPrompt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'baseSystemPrompt',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'baseSystemPrompt',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'baseSystemPrompt',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'baseSystemPrompt',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'baseSystemPrompt',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      baseSystemPromptIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'baseSystemPrompt',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'formatConstraint',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'formatConstraint',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'formatConstraint',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'formatConstraint',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'formatConstraint',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'formatConstraint',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'formatConstraint',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'formatConstraint',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'formatConstraint',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'formatConstraint',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'formatConstraint',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      formatConstraintIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'formatConstraint',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'fullOverride',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'fullOverride',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fullOverride',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'fullOverride',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'fullOverride',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'fullOverride',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'fullOverride',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'fullOverride',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'fullOverride',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'fullOverride',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fullOverride',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      fullOverrideIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'fullOverride',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      isAdvancedModeEqualTo(bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isAdvancedMode',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'label',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'label',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'label',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      labelIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'label',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sceneCode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'sceneCode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'sceneCode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'sceneCode',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'sceneCode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'sceneCode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'sceneCode',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'sceneCode',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sceneCode',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      sceneCodeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'sceneCode',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      updatedAtEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      updatedAtGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      updatedAtLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'updatedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      updatedAtBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'updatedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'userCustomPreference',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'userCustomPreference',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'userCustomPreference',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'userCustomPreference',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'userCustomPreference',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'userCustomPreference',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'userCustomPreference',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'userCustomPreference',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'userCustomPreference',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'userCustomPreference',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'userCustomPreference',
        value: '',
      ));
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterFilterCondition>
      userCustomPreferenceIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'userCustomPreference',
        value: '',
      ));
    });
  }
}

extension PromptTemplateQueryObject
    on QueryBuilder<PromptTemplate, PromptTemplate, QFilterCondition> {}

extension PromptTemplateQueryLinks
    on QueryBuilder<PromptTemplate, PromptTemplate, QFilterCondition> {}

extension PromptTemplateQuerySortBy
    on QueryBuilder<PromptTemplate, PromptTemplate, QSortBy> {
  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByBaseSystemPrompt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'baseSystemPrompt', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByBaseSystemPromptDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'baseSystemPrompt', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByFormatConstraint() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'formatConstraint', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByFormatConstraintDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'formatConstraint', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByFullOverride() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fullOverride', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByFullOverrideDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fullOverride', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByIsAdvancedMode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAdvancedMode', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByIsAdvancedModeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAdvancedMode', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> sortByLabel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> sortByLabelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> sortBySceneCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sceneCode', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortBySceneCodeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sceneCode', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> sortByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByUserCustomPreference() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'userCustomPreference', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      sortByUserCustomPreferenceDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'userCustomPreference', Sort.desc);
    });
  }
}

extension PromptTemplateQuerySortThenBy
    on QueryBuilder<PromptTemplate, PromptTemplate, QSortThenBy> {
  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByBaseSystemPrompt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'baseSystemPrompt', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByBaseSystemPromptDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'baseSystemPrompt', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByFormatConstraint() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'formatConstraint', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByFormatConstraintDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'formatConstraint', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByFullOverride() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fullOverride', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByFullOverrideDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fullOverride', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByIsAdvancedMode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAdvancedMode', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByIsAdvancedModeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isAdvancedMode', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> thenByLabel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> thenByLabelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> thenBySceneCode() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sceneCode', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenBySceneCodeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sceneCode', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy> thenByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByUpdatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'updatedAt', Sort.desc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByUserCustomPreference() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'userCustomPreference', Sort.asc);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QAfterSortBy>
      thenByUserCustomPreferenceDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'userCustomPreference', Sort.desc);
    });
  }
}

extension PromptTemplateQueryWhereDistinct
    on QueryBuilder<PromptTemplate, PromptTemplate, QDistinct> {
  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct>
      distinctByBaseSystemPrompt({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'baseSystemPrompt',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct>
      distinctByFormatConstraint({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'formatConstraint',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct>
      distinctByFullOverride({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'fullOverride', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct>
      distinctByIsAdvancedMode() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isAdvancedMode');
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct> distinctByLabel(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'label', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct> distinctBySceneCode(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sceneCode', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct>
      distinctByUpdatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'updatedAt');
    });
  }

  QueryBuilder<PromptTemplate, PromptTemplate, QDistinct>
      distinctByUserCustomPreference({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'userCustomPreference',
          caseSensitive: caseSensitive);
    });
  }
}

extension PromptTemplateQueryProperty
    on QueryBuilder<PromptTemplate, PromptTemplate, QQueryProperty> {
  QueryBuilder<PromptTemplate, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<PromptTemplate, String?, QQueryOperations>
      baseSystemPromptProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'baseSystemPrompt');
    });
  }

  QueryBuilder<PromptTemplate, String?, QQueryOperations>
      formatConstraintProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'formatConstraint');
    });
  }

  QueryBuilder<PromptTemplate, String?, QQueryOperations>
      fullOverrideProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'fullOverride');
    });
  }

  QueryBuilder<PromptTemplate, bool, QQueryOperations>
      isAdvancedModeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isAdvancedMode');
    });
  }

  QueryBuilder<PromptTemplate, String, QQueryOperations> labelProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'label');
    });
  }

  QueryBuilder<PromptTemplate, String, QQueryOperations> sceneCodeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sceneCode');
    });
  }

  QueryBuilder<PromptTemplate, DateTime, QQueryOperations> updatedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'updatedAt');
    });
  }

  QueryBuilder<PromptTemplate, String?, QQueryOperations>
      userCustomPreferenceProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'userCustomPreference');
    });
  }
}
