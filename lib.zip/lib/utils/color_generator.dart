
import 'dart:math';
import 'package:flutter/material.dart';

class ColorGenerator {
  /// 预设的一组低饱和度、高明度的马卡龙色系，适合做背景
  static const List<Color> _bgColors = [
    Color(0xFFE8F5E9), // 浅绿
    Color(0xFFE3F2FD), // 浅蓝
    Color(0xFFF3E5F5), // 浅紫
    Color(0xFFFFF3E0), // 浅橙
    Color(0xFFFFEBEE), // 浅红
    Color(0xFFE0F7FA), // 青色
    Color(0xFFFFF8E1), // 浅黄
    Color(0xFFF1F8E9), // 嫩绿
  ];

  /// 根据字符串生成固定的背景色
  static Color generateBgColor(String input) {
    if (input.isEmpty) return _bgColors[0];
    final int hash = input.hashCode;
    final int index = hash.abs() % _bgColors.length;
    return _bgColors[index];
  }

  /// 根据背景色计算合适的文字颜色 (通常是深色)
  static Color getTextColor(Color bgColor) {
    return HSLColor.fromColor(bgColor).withLightness(0.3).toColor();
  }
}
