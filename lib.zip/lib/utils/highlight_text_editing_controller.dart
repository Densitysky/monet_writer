
import 'package:flutter/material.dart';

class HighlightTextEditingController extends TextEditingController {
  // --- 临时高亮相关（用于 AI 生成反馈） ---
  TextRange? _tempHighlightRange;
  Color? _tempHighlightColor;

  // --- 关键词高亮相关（原有逻辑） ---
  Set<String> _keywords = {};

  // 设置临时高亮（例如：紫色锁定区 或 绿色结果区）
  void setTemporaryHighlight(int start, int end, Color color) {
    if (start >= end) return;
    _tempHighlightRange = TextRange(start: start, end: end);
    _tempHighlightColor = color;
    notifyListeners(); // 触发重绘
  }

  // 清除临时高亮
  void clearTemporaryHighlight() {
    if (_tempHighlightRange != null) {
      _tempHighlightRange = null;
      _tempHighlightColor = null;
      notifyListeners();
    }
  }

  // 更新关键词（原有功能保持不变）
  void updateKeywords(Set<String> newKeywords) {
    _keywords = newKeywords;
    notifyListeners();
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    // 1. 如果没有任何高亮需求，直接返回普通文本，保持高性能
    if ((_tempHighlightRange == null) && _keywords.isEmpty) {
      return super.buildTextSpan(context: context, style: style, withComposing: withComposing);
    }

    final List<TextSpan> children = [];
    final String text = this.text;

    // 简单起见，我们优先处理【临时高亮】，它的层级高于关键词
    // 如果存在临时高亮，我们把文本切成三段：[普通] [高亮] [普通]
    // (关键词高亮仅在普通段落中生效，暂不考虑叠加复杂情况)

    int currentIndex = 0;

    if (_tempHighlightRange != null) {
      final int start = _tempHighlightRange!.start.clamp(0, text.length);
      final int end = _tempHighlightRange!.end.clamp(0, text.length);

      // 第一段：高亮前的文本
      if (start > currentIndex) {
        children.add(_buildKeywordSpan(
          text.substring(currentIndex, start),
          style,
        ));
      }

      // 第二段：高亮文本 (应用背景色)
      if (end > start) {
        children.add(TextSpan(
          text: text.substring(start, end),
          style: style?.copyWith(
            backgroundColor: _tempHighlightColor,
          ),
        ));
      }

      // 更新索引
      currentIndex = end;
    }

    // 第三段/剩余文本
    if (currentIndex < text.length) {
      children.add(_buildKeywordSpan(
        text.substring(currentIndex),
        style,
      ));
    }

    return TextSpan(style: style, children: children);
  }

  // 辅助方法：处理关键词高亮（复用您原有的逻辑思路）
  TextSpan _buildKeywordSpan(String textSegment, TextStyle? style) {
    if (_keywords.isEmpty) return TextSpan(text: textSegment, style: style);

    final List<TextSpan> spans = [];
    final pattern = RegExp(_keywords.map(RegExp.escape).join('|'));

    textSegment.splitMapJoin(
      pattern,
      onMatch: (m) {
        spans.add(TextSpan(
          text: m[0],
          style: style?.copyWith(
            color: Colors.blueAccent, // 关键词颜色保持原有设定
            fontWeight: FontWeight.bold,
          ),
        ));
        return '';
      },
      onNonMatch: (n) {
        spans.add(TextSpan(text: n, style: style));
        return '';
      },
    );

    return TextSpan(children: spans);
  }
}
