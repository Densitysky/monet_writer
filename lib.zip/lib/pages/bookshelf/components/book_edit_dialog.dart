
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import 'package:monet_writer/models/book.dart';
import 'package:monet_writer/services/database_service.dart';
import 'package:monet_writer/widgets/monet_text_field.dart'; // 【引入新组件】

class BookEditPanel extends StatefulWidget {
  final Book? book;

  const BookEditPanel({super.key, this.book});

  @override
  State<BookEditPanel> createState() => _BookEditPanelState();
}

class _BookEditPanelState extends State<BookEditPanel> {
  final _titleController = TextEditingController();
  final _authorController = TextEditingController();
  final _descController = TextEditingController();

  String? _coverPath;
  int _status = 0; // 0: 连载中, 1: 已完结

  bool get isEditing => widget.book != null;

  @override
  void initState() {
    super.initState();
    if (isEditing) {
      _titleController.text = widget.book!.title;
      _authorController.text = widget.book!.authorName ?? '';
      _descController.text = widget.book!.description ?? '';
      _coverPath = widget.book!.coverPath;
      _status = widget.book!.status;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _authorController.dispose();
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildHeroCover(context),
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // 【使用新组件】替换了原有的 _buildInput
                      MonetTextField(
                        controller: _titleController,
                        label: '书名',
                        hint: '请输入书名',
                        icon: Icons.auto_stories,
                        autoFocus: !isEditing, // 新建时自动聚焦
                      ),
                      const SizedBox(height: 20),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: MonetTextField(
                              controller: _authorController,
                              label: '作者',
                              hint: '佚名',
                              icon: Icons.person,
                            ),
                          ),
                          const SizedBox(width: 16),
                          _buildStatusToggle(theme),
                        ],
                      ),
                      const SizedBox(height: 20),
                      MonetTextField(
                        controller: _descController,
                        label: '简介',
                        hint: '一句话介绍你的故事...',
                        icon: Icons.notes,
                        maxLines: 5,
                        minLines: 3,
                      ),
                      SizedBox(height: bottomInset > 0 ? bottomInset + 20 : 100),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey.withOpacity(0.1))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消', style: TextStyle(color: Colors.grey)),
          ),
          Text(
            isEditing ? '书籍设置' : '新建书籍',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          FilledButton.tonal(
            onPressed: _save,
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCover(BuildContext context) {
    final hasCover = _coverPath != null && File(_coverPath!).existsSync();
    final theme = Theme.of(context);

    return SizedBox(
      height: 220,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // 背景模糊层
          Positioned.fill(
            child: hasCover
                ? ImageFiltered(
              imageFilter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: Image.file(
                File(_coverPath!),
                fit: BoxFit.cover,
                color: Colors.black.withOpacity(0.2),
                colorBlendMode: BlendMode.darken,
              ),
            )
                : Container(
              color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
            ),
          ),

          // 封面主体
          GestureDetector(
            onTap: _pickCover,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 110,
                  height: 146,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (hasCover)
                        Image.file(File(_coverPath!), fit: BoxFit.cover)
                      else
                        Center(
                          child: Icon(Icons.add_photo_alternate_outlined,
                              size: 40, color: theme.colorScheme.primary),
                        ),

                      // 编辑角标
                      Positioned(
                        bottom: 0, left: 0, right: 0,
                        child: Container(
                          height: 30,
                          color: Colors.black.withOpacity(0.5),
                          alignment: Alignment.center,
                          child: const Text(
                              '点击更换',
                              style: TextStyle(color: Colors.white, fontSize: 10)
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusToggle(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 保持高度与 Input 对齐
        Container(
          height: 56,
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildStatusBtn(0, '连载', Colors.green),
              _buildStatusBtn(1, '完结', Colors.red),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatusBtn(int value, String text, Color activeColor) {
    final isSelected = _status == value;
    return GestureDetector(
      onTap: () => setState(() => _status = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          boxShadow: isSelected
              ? [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4)]
              : null,
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 14,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? activeColor : Colors.grey,
          ),
        ),
      ),
    );
  }

  Future<void> _pickCover() async {
    final picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    CroppedFile? croppedFile = await ImageCropper().cropImage(
      sourcePath: image.path,
      aspectRatio: const CropAspectRatio(ratioX: 3, ratioY: 4),
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: '裁剪封面',
          toolbarColor: Theme.of(context).colorScheme.surface,
          statusBarColor: Theme.of(context).colorScheme.surface,
          toolbarWidgetColor: Theme.of(context).colorScheme.onSurface,
          activeControlsWidgetColor: Theme.of(context).colorScheme.primary,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: true,
        ),
        IOSUiSettings(title: '裁剪封面', aspectRatioLockEnabled: true),
      ],
    );
    if (croppedFile != null) {
      setState(() => _coverPath = croppedFile.path);
    }
  }

  Future<void> _save() async {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请输入书名')));
      return;
    }

    final author = _authorController.text.trim().isEmpty ? '佚名' : _authorController.text.trim();
    final desc = _descController.text.trim();

    String? finalCoverPath = _coverPath;
    if (_coverPath != widget.book?.coverPath && _coverPath != null) {
      final directory = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final savedImage = await File(_coverPath!).copy('${directory.path}/cover_$timestamp.jpg');
      finalCoverPath = savedImage.path;
    }

    final isar = DatabaseService().isar;
    if (isEditing) {
      await isar.writeTxn(() async {
        final book = widget.book!;
        book.title = title;
        book.authorName = author;
        book.description = desc;
        book.coverPath = finalCoverPath;
        book.status = _status;
        book.updatedAt = DateTime.now();
        await isar.books.put(book);
      });
    } else {
      final newBook = Book()
        ..title = title
        ..authorName = author
        ..description = desc
        ..coverPath = finalCoverPath
        ..status = _status
        ..createdAt = DateTime.now()
        ..updatedAt = DateTime.now();
      await isar.writeTxn(() async {
        await isar.books.put(newBook);
      });
    }
    if (mounted) Navigator.pop(context);
  }
}
