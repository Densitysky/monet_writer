
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:monet_writer/providers/theme_provider.dart';
import 'package:monet_writer/providers/user_provider.dart';
import 'package:monet_writer/pages/settings/ai_config_page.dart';
import 'package:monet_writer/pages/settings/data_manage_page.dart';
// 【关键修复】找回丢失的提示词页面引用
import 'package:monet_writer/pages/settings/ai_prompts_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final themeProvider = context.watch<ThemeProvider>();
    final userProvider = context.watch<UserProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
      ),
      body: ListView(
        children: [
          const SizedBox(height: 10),

          // --- 分组 1: 个性化 ---
          _SectionHeader(title: '个性化'),
          SwitchListTile(
            title: const Text('主页背景模糊'),
            subtitle: const Text('开启后，个人中心背景图将应用高斯模糊'),
            value: userProvider.isBackgroundBlurred,
            onChanged: (value) {
              userProvider.toggleBackgroundBlur(value);
            },
          ),
          ListTile(
            title: const Text('主题颜色'),
            subtitle: Text('当前色值: #${themeProvider.seedColor.value.toRadixString(16).substring(2).toUpperCase()}'),
            trailing: CircleAvatar(backgroundColor: themeProvider.seedColor, radius: 12),
            onTap: () => _showColorPicker(context, themeProvider),
          ),
          ListTile(
            title: const Text('夜间模式'),
            subtitle: Text(_getThemeModeText(themeProvider.themeMode)),
            trailing: const Icon(Icons.brightness_6),
            onTap: () => _showThemeModeDialog(context, themeProvider),
          ),

          const Divider(),

          // --- 分组 2: AI 与 写作 ---
          _SectionHeader(title: '智能与写作'),
          ListTile(
            leading: const Icon(Icons.psychology),
            title: const Text('AI 模型配置'),
            subtitle: const Text('API Key、模型选择、基础设定'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const AiConfigPage()));
            },
          ),
          // 【关键修复】恢复“AI 提示词配置”入口
          ListTile(
            leading: const Icon(Icons.abc, color: Colors.indigo),
            title: const Text('AI 提示词配置'),
            subtitle: const Text('自定义角色提取、大纲生成等 Prompt'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const AiPromptsPage()));
            },
          ),

          const Divider(),

          // --- 分组 3: 数据安全 ---
          _SectionHeader(title: '数据安全'),
          ListTile(
            leading: const Icon(Icons.save_as, color: Colors.blue),
            title: const Text('数据备份与恢复'),
            subtitle: const Text('导出数据包、迁移数据到新设备'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const DataManagePage()));
            },
          ),

          const Divider(),

          // --- 分组 4: 关于 ---
          _SectionHeader(title: '关于'),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('关于落笔'),
            subtitle: const Text('v1.0.3 Beta'),
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: '落笔',
                applicationVersion: '1.0.4',
                applicationLegalese: 'Designed for Writers.',
                applicationIcon: Container(
                  width: 50, height: 50,
                  color: theme.colorScheme.primaryContainer,
                  child: const Icon(Icons.edit_note),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  String _getThemeModeText(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.system: return '跟随系统';
      case ThemeMode.light: return '浅色模式';
      case ThemeMode.dark: return '深色模式';
    }
  }

  void _showColorPicker(BuildContext context, ThemeProvider provider) {
    final colors = [
      Colors.blue, Colors.purple, Colors.green, Colors.orange,
      Colors.red, Colors.teal, Colors.pink, Colors.indigo
    ];

    showModalBottomSheet(
      context: context,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        height: 200,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('选择主题色', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 6, crossAxisSpacing: 10, mainAxisSpacing: 10
                ),
                itemCount: colors.length,
                itemBuilder: (_, i) {
                  final c = colors[i];
                  return GestureDetector(
                    onTap: () {
                      provider.setSeedColor(c);
                      Navigator.pop(ctx);
                    },
                    child: CircleAvatar(backgroundColor: c),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  void _showThemeModeDialog(BuildContext context, ThemeProvider provider) {
    showDialog(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('选择模式'),
        children: [
          SimpleDialogOption(child: const Text('跟随系统'), onPressed: () { provider.setThemeMode(ThemeMode.system); Navigator.pop(context); }),
          SimpleDialogOption(child: const Text('浅色模式'), onPressed: () { provider.setThemeMode(ThemeMode.light); Navigator.pop(context); }),
          SimpleDialogOption(child: const Text('深色模式'), onPressed: () { provider.setThemeMode(ThemeMode.dark); Navigator.pop(context); }),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
      ),
    );
  }
}
