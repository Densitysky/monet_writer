
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

import 'package:monet_writer/models/book.dart';
import 'package:monet_writer/providers/user_provider.dart';
import 'package:monet_writer/providers/writing_provider.dart';

import 'package:monet_writer/pages/writing/components/writing_drawer.dart';
import 'package:monet_writer/pages/writing/components/keyboard_toolbar.dart';
import 'package:monet_writer/pages/writing/components/right_drawer.dart';
import 'package:monet_writer/pages/editor/ai_assistant_sheet.dart';
import 'package:monet_writer/pages/writing/components/monet_selection_controls.dart';
import 'package:monet_writer/pages/writing/components/ai_input_toolbar.dart';

class WritingPage extends StatelessWidget {
  final Book book;
  final int initialChapterIndex;

  const WritingPage({
    super.key,
    required this.book,
    this.initialChapterIndex = -1,
  });

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => WritingProvider(book: book),
      child: _WritingPageContent(initialChapterIndex: initialChapterIndex),
    );
  }
}

class _WritingPageContent extends StatefulWidget {
  final int initialChapterIndex;
  const _WritingPageContent({required this.initialChapterIndex});

  @override
  State<_WritingPageContent> createState() => _WritingPageContentState();
}

class _WritingPageContentState extends State<_WritingPageContent> with WidgetsBindingObserver {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _hasInitialized = false;
  bool _isKeyboardVisible = false;

  // 控制是否显示底部 AI 输入栏
  bool _showAiInput = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    final bottomInset = View.of(context).viewInsets.bottom;
    final newValue = bottomInset > 0.0;
    if (newValue != _isKeyboardVisible) {
      setState(() {
        _isKeyboardVisible = newValue;
      });
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_hasInitialized) {
      if (widget.initialChapterIndex >= 0) {
        final provider = context.read<WritingProvider>();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          provider.loadChapterByIndex(widget.initialChapterIndex);
        });
      }
      _hasInitialized = true;
    }
  }

  Future<void> _pickImage(WritingProvider provider) async {
    final picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      final appDir = await getApplicationDocumentsDirectory();
      final fileName = '${DateTime.now().millisecondsSinceEpoch}${p.extension(image.path)}';
      final savedImage = await File(image.path).copy('${appDir.path}/$fileName');

      provider.insertText('\n![image](${savedImage.path})\n');
    }
  }

  // 这个 Sheet 方法可能已经不常用了，但保留作为备选入口
  void _openAiAssistant(WritingProvider provider) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => AiAssistantSheet(
        contextSummary: provider.contentController.text,
        onResult: (resultText) {
          provider.insertText(resultText);
        },
      ),
    );
  }

  // 回调：当点击悬浮菜单的 AI 按钮时触发
  void _onAiModeTriggered() {
    setState(() {
      _showAiInput = true;
    });
  }

  // 回调：关闭 AI 输入栏
  void _closeAiInput() {
    setState(() {
      _showAiInput = false;
    });
    // 关闭时清除高亮（如果是手动取消的）
    context.read<WritingProvider>().clearAiHighlight();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final userProvider = context.watch<UserProvider>();
    final provider = context.watch<WritingProvider>();

    // 创建 Controls，传入回调
    final selectionControls = MonetSelectionControls(
      provider: provider,
      onAiInputTriggered: _onAiModeTriggered,
    );

    final wordCount = provider.contentController.text.length;

    BoxDecoration? bgDecoration;
    if (userProvider.backgroundImagePath != null) {
      final file = File(userProvider.backgroundImagePath!);
      if (file.existsSync()) {
        bgDecoration = BoxDecoration(
          image: DecorationImage(
            image: FileImage(file),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.2),
                BlendMode.darken
            ),
          ),
        );
      }
    }

    final backgroundColor = userProvider.currentTheme.backgroundColor;
    final headerTextColor = userProvider.currentTheme.textColor.withOpacity(0.7);

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: backgroundColor,
      drawer: const WritingDrawer(),
      endDrawer: const RightDrawer(),
      drawerEnableOpenDragGesture: false,
      endDrawerEnableOpenDragGesture: false,
      resizeToAvoidBottomInset: true,

      body: Container(
        decoration: bgDecoration ?? BoxDecoration(color: backgroundColor),
        child: SafeArea(
          child: Column(
            children: [
              Container(
                height: 50,
                padding: const EdgeInsets.symmetric(horizontal: 4),
                color: Colors.transparent,
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back_ios_new, size: 20, color: headerTextColor),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Expanded(
                      child: Center(
                        child: TextField(
                          controller: provider.titleController,
                          textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            hintText: '无标题',
                            isDense: true,
                          ),
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: userProvider.currentTheme.textColor,
                          ),
                          onChanged: (_) => provider.onTextChanged(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 16.0),
                      child: Text(
                        '$wordCount字',
                        style: TextStyle(fontSize: 12, color: headerTextColor),
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: TextField(
                        controller: provider.contentController,
                        // 【关键】绑定 ScrollController
                        scrollController: provider.scrollController,
                        maxLines: null,
                        expands: true,
                        selectionControls: selectionControls,
                        decoration: const InputDecoration(border: InputBorder.none, hintText: '开始创作...'),
                        style: TextStyle(
                          fontSize: userProvider.fontSize,
                          height: userProvider.lineHeight,
                          fontFamily: userProvider.fontFamily,
                          color: userProvider.currentTheme.textColor,
                        ),
                        cursorColor: userProvider.currentTheme.cursorColor,
                        onChanged: (_) => provider.onContentChanged(),
                        // 当点击空白处时，清除可能存在的高亮
                        onTapOutside: (_) => provider.clearAiHighlight(),
                      ),
                    ),
                    Positioned(
                      left: 0, top: 0, bottom: 0, width: 40,
                      child: GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        onDoubleTap: () => _scaffoldKey.currentState?.openDrawer(),
                      ),
                    ),
                    Positioned(
                      right: 0, top: 0, bottom: 0, width: 40,
                      child: GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        onDoubleTap: () => _scaffoldKey.currentState?.openEndDrawer(),
                      ),
                    ),
                  ],
                ),
              ),

              // 底部栏切换逻辑
              if (_showAiInput)
                AiInputToolbar(onClose: _closeAiInput)
              else if (_isKeyboardVisible)
                KeyboardToolbar(
                  onInsertImage: () => _pickImage(provider),
                  // onOpenAI 移除
                ),
            ],
          ),
        ),
      ),
    );
  }
}
