
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:isar/isar.dart';
import 'package:monet_writer/models/chapter.dart';
import 'package:monet_writer/services/database_service.dart';
import 'package:monet_writer/providers/writing_provider.dart';

class WritingDrawer extends StatelessWidget {
  const WritingDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.watch<WritingProvider>();
    final topPadding = MediaQuery.of(context).padding.top;

    return Drawer(
      width: MediaQuery.of(context).size.width * 0.75,
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        margin: EdgeInsets.only(
          top: topPadding + 10,
          bottom: 40,
          left: 10,
          right: 0,
        ),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.15),
              blurRadius: 20,
              offset: const Offset(5, 5),
            ),
          ],
        ),
        child: FutureBuilder<List<Chapter>>(
          future: DatabaseService().isar.chapters
              .filter()
              .bookIdEqualTo(provider.book.id)
              .sortByOrderIndex()
              .findAll(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final chapters = snapshot.data!;

            return Column(
              children: [
                // 头部
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer.withOpacity(0.5),
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: theme.colorScheme.primary,
                        child: Text(
                          provider.book.title.isNotEmpty ? provider.book.title[0] : '无',
                          style: TextStyle(color: theme.colorScheme.onPrimary),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(provider.book.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            Text('共 ${chapters.length} 章', style: TextStyle(color: theme.colorScheme.onSurfaceVariant, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // 列表
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.zero,
                    itemCount: chapters.length,
                    itemBuilder: (ctx, index) {
                      final chapter = chapters[index];
                      final isSelected = provider.currentChapter?.id == chapter.id;

                      return ListTile(
                        selected: isSelected,
                        selectedTileColor: theme.colorScheme.primaryContainer,
                        title: Text(chapter.title, style: TextStyle(
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          color: isSelected ? theme.colorScheme.primary : null,
                        )),
                        subtitle: Text('${chapter.wordCount} 字', style: const TextStyle(fontSize: 10)),
                        onTap: () {
                          provider.selectChapter(chapter);
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),

                // 底部按钮
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: FilledButton.icon(
                    onPressed: () => _showCreateDialog(context, provider),
                    icon: const Icon(Icons.add),
                    label: const Text('新建章节'),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _showCreateDialog(BuildContext context, WritingProvider provider) async {
    final count = await DatabaseService().isar.chapters.filter().bookIdEqualTo(provider.book.id).count();
    final defaultTitle = '第${count + 1}章';
    final controller = TextEditingController(text: defaultTitle);

    if (!context.mounted) return;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('新建章节'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: '章节标题'),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          TextButton(
            onPressed: () async {
              if (controller.text.isNotEmpty) {
                Navigator.pop(context);
                provider.createChapter(controller.text);
              }
            },
            child: const Text('创建'),
          ),
        ],
      ),
    );
  }
}
