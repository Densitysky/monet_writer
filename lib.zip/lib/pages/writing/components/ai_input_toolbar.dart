
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:monet_writer/providers/writing_provider.dart';
import 'package:monet_writer/services/database_service.dart';
import 'package:monet_writer/models/ai_config.dart';

enum _AiStatus { input, loading, success }

class AiInputToolbar extends StatefulWidget {
  final VoidCallback onClose;

  const AiInputToolbar({
    super.key,
    required this.onClose,
  });

  @override
  State<AiInputToolbar> createState() => _AiInputToolbarState();
}

class _AiInputToolbarState extends State<AiInputToolbar> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  _AiStatus _status = _AiStatus.input;

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // 辅助方法：获取当前的 AI 配置
  // 如果您有 SettingsProvider，也可以用 context.read<SettingsProvider>().currentConfig
  Future<AiConfig> _getConfig() async {
    final db = DatabaseService();
    // 假设获取第一个激活的配置，或者最近使用的配置
    final configs = await db.getAllAiConfigs();
    if (configs.isEmpty) {
      throw Exception("未找到可用的 AI 配置，请先在设置中添加模型。");
    }
    // 简单策略：优先取第一个，或者取 isEnabled=true 的
    // 实际项目中这里应该由用户指定使用哪个模型
    return configs.first;
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    // 1. 切换到生成中状态
    setState(() => _status = _AiStatus.loading);

    try {
      // 2. 获取配置
      final config = await _getConfig();

      // 3. 调用 Provider (传入 config)
      final provider = context.read<WritingProvider>();
      await provider.replaceSelectionWithAi(config, text);

      // 4. 生成成功，显示完成提示
      if (mounted) {
        setState(() => _status = _AiStatus.success);
      }

      // 5. 停留 800ms 让用户看到“完成”状态
      await Future.delayed(const Duration(milliseconds: 800));

      // 6. 关闭工具栏
      if (mounted) {
        widget.onClose();
      }
    } catch (e) {
      // 失败回退到输入状态，允许重试
      if (mounted) {
        setState(() => _status = _AiStatus.input);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('AI 请求失败: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1E1E1E) : Colors.white;
    final accentColor = Colors.purpleAccent;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: bgColor,
        border: Border(
          top: BorderSide(color: accentColor.withOpacity(0.5), width: 1),
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4, offset: const Offset(0, -2)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          child: _buildContent(isDark, accentColor),
        ),
      ),
    );
  }

  Widget _buildContent(bool isDark, Color accentColor) {
    switch (_status) {
      case _AiStatus.loading:
        return _buildStatusRow(
          const SizedBox(
            width: 18, height: 18,
            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.purpleAccent),
          ),
          "AI 正在生成中...",
          accentColor,
        );

      case _AiStatus.success:
        return _buildStatusRow(
          const Icon(Icons.check_circle, color: Colors.greenAccent, size: 20),
          "生成完成",
          Colors.greenAccent,
        );

      case _AiStatus.input:
      default:
        return _buildInputRow(isDark, accentColor);
    }
  }

  Widget _buildInputRow(bool isDark, Color accentColor) {
    return Row(
      key: const ValueKey('input'),
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: Icon(Icons.auto_awesome, color: accentColor, size: 20),
        ),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: isDark ? Colors.white10 : Colors.grey.shade100,
              borderRadius: BorderRadius.circular(20),
            ),
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              autofocus: true,
              style: TextStyle(fontSize: 14, color: isDark ? Colors.white : Colors.black87),
              decoration: const InputDecoration(
                hintText: "告诉 AI 怎么改... (如：扩写这段话)",
                hintStyle: TextStyle(fontSize: 14, color: Colors.grey),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _send(),
            ),
          ),
        ),
        const SizedBox(width: 8),
        IconButton(
          icon: Icon(Icons.arrow_upward_rounded, color: accentColor),
          onPressed: _send,
          tooltip: '发送',
          constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
        ),
        IconButton(
          icon: Icon(Icons.close, color: Colors.grey),
          onPressed: widget.onClose,
          tooltip: '取消',
          constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
        ),
      ],
    );
  }

  Widget _buildStatusRow(Widget icon, String text, Color textColor) {
    return Container(
      key: ValueKey(text),
      height: 48,
      alignment: Alignment.center,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          icon,
          const SizedBox(width: 12),
          Text(text, style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 15)),
        ],
      ),
    );
  }
}
