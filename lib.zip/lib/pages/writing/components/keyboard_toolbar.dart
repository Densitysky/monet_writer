
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:monet_writer/providers/writing_provider.dart';

class KeyboardToolbar extends StatelessWidget {
  final VoidCallback? onInsertImage;

  const KeyboardToolbar({
    super.key,
    this.onInsertImage,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.read<WritingProvider>();

    return Container(
      height: 48,
      color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.9),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        children: [
          // 图片插入
          if (onInsertImage != null)
            _ToolbarIconButton(
              icon: Icons.image_outlined,
              onPressed: onInsertImage,
            ),

          const VerticalDivider(indent: 12, endIndent: 12, width: 20),

          // 撤销/重做
          ValueListenableBuilder<UndoHistoryValue>(
            valueListenable: provider.undoController,
            builder: (context, value, child) {
              return Row(
                children: [
                  _ToolbarIconButton(
                    icon: Icons.undo,
                    onPressed: value.canUndo ? () {
                      HapticFeedback.lightImpact();
                      provider.undoController.undo();
                    } : null,
                  ),
                  _ToolbarIconButton(
                    icon: Icons.redo,
                    onPressed: value.canRedo ? () {
                      HapticFeedback.lightImpact();
                      provider.undoController.redo();
                    } : null,
                  ),
                ],
              );
            },
          ),

          const VerticalDivider(indent: 12, endIndent: 12, width: 20),

          // 常用标点
          _buildQuickInput(provider, '“', '”'),
          _buildQuickInput(provider, '……', ''),
          _buildQuickInput(provider, '——', ''),

          const VerticalDivider(indent: 12, endIndent: 12, width: 20),

          // 收起键盘
          _ToolbarIconButton(
            icon: Icons.keyboard_hide,
            onPressed: () => FocusScope.of(context).unfocus(),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickInput(WritingProvider provider, String start, String end) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      child: TextButton(
        onPressed: () {
          HapticFeedback.lightImpact();
          provider.insertText(start + end);
          if (end.isNotEmpty) {
            provider.moveCursor(-end.length);
          }
        },
        style: TextButton.styleFrom(
          minimumSize: const Size(36, 32),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          backgroundColor: Colors.black.withOpacity(0.05),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        child: Text(
            start + end,
            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black87, fontSize: 13)
        ),
      ),
    );
  }
}

class _ToolbarIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onPressed;
  const _ToolbarIconButton({required this.icon, this.onPressed});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(icon, size: 20),
      onPressed: onPressed,
      visualDensity: VisualDensity.compact,
      padding: const EdgeInsets.all(8),
    );
  }
}
