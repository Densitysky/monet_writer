
import 'dart:ui';
import 'package:flutter/material.dart';
import 'right_drawer_views/root_view.dart';
import 'right_drawer_views/outline_view.dart';
import 'right_drawer_views/settings_view.dart';
import 'right_drawer_views/character_view.dart';

enum MenuLevel { root, outline, character, settings }

class RightDrawer extends StatefulWidget {
  // 【新增】接收初始索引
  final int? initialIndex;

  const RightDrawer({super.key, this.initialIndex});

  @override
  State<RightDrawer> createState() => _RightDrawerState();
}

class _RightDrawerState extends State<RightDrawer> {
  MenuLevel _currentLevel = MenuLevel.root;
  String _title = '工具箱';

  @override
  void initState() {
    super.initState();
    // 【关键逻辑】根据传入的索引初始化页面状态
    if (widget.initialIndex != null) {
      _handleInitialIndex(widget.initialIndex!);
    }
  }

  void _handleInitialIndex(int index) {
    switch (index) {
      case 0: // 0 对应大纲
        _currentLevel = MenuLevel.outline;
        _title = '大纲管理';
        break;
      case 1: // 1 对应角色
        _currentLevel = MenuLevel.character;
        _title = '角色管理';
        break;
    // 后续如果有更多入口可以在这里扩展
      default:
        _currentLevel = MenuLevel.root;
        _title = '工具箱';
    }
  }

  void _navigateTo(MenuLevel level, String title) {
    setState(() {
      _currentLevel = level;
      _title = title;
    });
  }

  void _navigateBack() {
    setState(() {
      _currentLevel = MenuLevel.root;
      _title = '工具箱';
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final topPadding = MediaQuery.of(context).padding.top;

    return Drawer(
      width: MediaQuery.of(context).size.width * 0.75,
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        margin: EdgeInsets.only(
          top: topPadding + 10,
          bottom: 40,
          right: 10,
          left: 0,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              decoration: BoxDecoration(
                color: theme.colorScheme.surface.withOpacity(0.85),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 20,
                    offset: const Offset(-5, 5),
                  ),
                ],
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: Column(
                children: [
                  // --- Header ---
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(0.3))),
                    ),
                    child: Row(
                      children: [
                        if (_currentLevel == MenuLevel.root)
                          Icon(Icons.widgets_outlined, color: theme.colorScheme.primary)
                        else
                          IconButton(
                            icon: const Icon(Icons.arrow_back_ios, size: 18),
                            onPressed: _navigateBack,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),

                        const SizedBox(width: 12),

                        Expanded(
                          child: Text(
                            _title,
                            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                          ),
                        ),

                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(context),
                        )
                      ],
                    ),
                  ),

                  // --- Body ---
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      transitionBuilder: (Widget child, Animation<double> animation) {
                        final offsetAnimation = Tween<Offset>(
                          begin: const Offset(1.0, 0.0),
                          end: Offset.zero,
                        ).animate(animation);
                        return SlideTransition(position: offsetAnimation, child: child);
                      },
                      child: _buildBody(context),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    switch (_currentLevel) {
      case MenuLevel.root:
        return RootView(
          key: const ValueKey('root'),
          onNavigate: (levelKey, title) {
            MenuLevel level;
            if (levelKey == 'outline') {
              level = MenuLevel.outline;
            } else if (levelKey == 'settings') {
              level = MenuLevel.settings;
            } else {
              level = MenuLevel.character;
            }
            _navigateTo(level, title);
          },
        );
      case MenuLevel.settings:
        return const SettingsView(key: ValueKey('settings'));
      case MenuLevel.outline:
        return const OutlineView(key: ValueKey('outline'));
      case MenuLevel.character:
        return const CharacterView(key: ValueKey('character'));
    }
  }
}
