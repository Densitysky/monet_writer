
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:monet_writer/providers/writing_provider.dart';

/// 自定义文本选择控制器
class MonetSelectionControls extends MaterialTextSelectionControls {
  final WritingProvider provider;
  // 【新增】回调：通知页面显示底部输入栏
  final VoidCallback onAiInputTriggered;

  MonetSelectionControls({
    required this.provider,
    required this.onAiInputTriggered,
  });

  @override
  Widget buildToolbar(
      BuildContext context,
      Rect globalEditableRegion,
      double textLineHeight,
      Offset selectionMidpoint,
      List<TextSelectionPoint> endpoints,
      TextSelectionDelegate delegate,
      ValueListenable<ClipboardStatus>? clipboardStatus,
      Offset? lastSecondaryTapDownPosition,
      ) {
    return _MonetToolbar(
      globalEditableRegion: globalEditableRegion,
      textLineHeight: textLineHeight,
      selectionMidpoint: selectionMidpoint,
      endpoints: endpoints,
      delegate: delegate,
      clipboardStatus: clipboardStatus,
      provider: provider,
      onAiInputTriggered: onAiInputTriggered,
      handleCut: (delegate) => handleCut(delegate),
      handleCopy: (delegate) => handleCopy(delegate),
      handlePaste: (delegate) => handlePaste(delegate),
      handleSelectAll: (delegate) => handleSelectAll(delegate),
    );
  }
}

class _MonetToolbar extends StatelessWidget {
  final Rect globalEditableRegion;
  final double textLineHeight;
  final Offset selectionMidpoint;
  final List<TextSelectionPoint> endpoints;
  final TextSelectionDelegate delegate;
  final ValueListenable<ClipboardStatus>? clipboardStatus;
  final WritingProvider provider;
  final VoidCallback onAiInputTriggered;

  final Function(TextSelectionDelegate) handleCut;
  final Function(TextSelectionDelegate) handleCopy;
  final Function(TextSelectionDelegate) handlePaste;
  final Function(TextSelectionDelegate) handleSelectAll;

  const _MonetToolbar({
    required this.globalEditableRegion,
    required this.textLineHeight,
    required this.selectionMidpoint,
    required this.endpoints,
    required this.delegate,
    this.clipboardStatus,
    required this.provider,
    required this.onAiInputTriggered,
    required this.handleCut,
    required this.handleCopy,
    required this.handlePaste,
    required this.handleSelectAll,
  });

  void _onSelectParagraph() {
    provider.selectCurrentParagraph();
  }

  void _onAiClick() {
    // 触发回调，由 WritingPage 处理显示底部栏
    onAiInputTriggered();
    // 隐藏当前的悬浮菜单
    delegate.hideToolbar();
  }

  @override
  Widget build(BuildContext context) {
    // 计算位置 (保持不变)
    final MediaQueryData mediaQuery = MediaQuery.of(context);
    final double screenWidth = mediaQuery.size.width;

    double toolbarY = endpoints.first.point.dy - textLineHeight - 70;
    double toolbarX = selectionMidpoint.dx - 160;

    if (toolbarX < 10) toolbarX = 10;
    if (toolbarX + 320 > screenWidth) toolbarX = screenWidth - 330;

    if (toolbarY < mediaQuery.padding.top + 50) {
      toolbarY = endpoints.last.point.dy + 20;
    }

    return Stack(
      children: [
        Positioned(
          left: toolbarX,
          top: toolbarY,
          child: Material(
            color: Colors.transparent,
            type: MaterialType.transparency,
            child: Container(
              constraints: const BoxConstraints(minWidth: 200, maxWidth: 320),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
                border: Border.all(color: Colors.white10, width: 0.5),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _MenuButton(
                        label: '剪切',
                        onTap: () {
                          handleCut(delegate);
                          delegate.hideToolbar();
                        },
                      ),
                      _MenuButton(
                        label: '复制',
                        onTap: () {
                          handleCopy(delegate);
                          delegate.hideToolbar();
                        },
                      ),
                      ValueListenableBuilder<ClipboardStatus>(
                        valueListenable: clipboardStatus ?? ValueNotifier(ClipboardStatus.unknown),
                        builder: (context, status, child) {
                          if (status == ClipboardStatus.pasteable) {
                            return _MenuButton(
                              label: '粘贴',
                              onTap: () {
                                handlePaste(delegate);
                                delegate.hideToolbar();
                              },
                            );
                          }
                          return const SizedBox.shrink();
                        },
                      ),
                      _MenuButton(
                        label: '全选',
                        onTap: () => handleSelectAll(delegate),
                      ),
                      Container(
                          width: 1, height: 16, color: Colors.white24,
                          margin: const EdgeInsets.symmetric(horizontal: 4)
                      ),
                      _MenuButton(
                        label: '选段',
                        icon: Icons.segment,
                        onTap: _onSelectParagraph,
                      ),
                      _MenuButton(
                        label: 'AI',
                        icon: Icons.auto_awesome,
                        iconColor: Colors.purpleAccent,
                        textColor: Colors.purpleAccent,
                        onTap: _onAiClick,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _MenuButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback onTap;
  final Color textColor;
  final Color iconColor;

  const _MenuButton({
    required this.label,
    required this.onTap,
    this.icon,
    this.textColor = Colors.white,
    this.iconColor = Colors.white70,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: Row(
          children: [
            if (icon != null) ...[
              Icon(icon, size: 14, color: iconColor),
              const SizedBox(width: 4),
            ],
            Text(label, style: TextStyle(color: textColor, fontSize: 13, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}
