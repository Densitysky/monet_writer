
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:monet_writer/providers/writing_provider.dart';
import 'package:monet_writer/models/character.dart';
import 'package:monet_writer/models/character_group.dart';
import 'package:monet_writer/pages/writing/character_profile_page.dart';
import 'package:monet_writer/pages/writing/components/character_card.dart';
import 'package:monet_writer/services/ai_service.dart';

class CharacterView extends StatefulWidget {
  const CharacterView({super.key});

  @override
  State<CharacterView> createState() => _CharacterViewState();
}

class _CharacterViewState extends State<CharacterView> {
  bool _isExtracting = false;

  @override
  Widget build(BuildContext context) {
    // 这里 watch 是为了监听列表变化，比如新增角色后刷新列表
    final provider = context.watch<WritingProvider>();
    final theme = Theme.of(context);

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            children: [
              _buildSectionHeader(context, '角色管理'),

              // 1. 分组列表 (文件夹)
              if (provider.book.characterGroups != null)
                ...List.generate(provider.book.characterGroups!.length, (gIndex) {
                  final group = provider.book.characterGroups![gIndex];
                  return _buildGroupItem(context, provider, group, gIndex);
                }),

              // 2. 根目录列表 (单体角色)
              if (provider.book.characters != null)
                ...List.generate(provider.book.characters!.length, (cIndex) {
                  final character = provider.book.characters![cIndex];
                  return _buildDraggableCharacterItem(
                    context,
                    provider,
                    character,
                    cIndex,
                    null,
                  );
                }),

              const SizedBox(height: 80),
            ],
          ),
        ),

        // 底部操作栏
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            border: Border(top: BorderSide(color: theme.colorScheme.outlineVariant.withOpacity(0.3))),
          ),
          child: Row(
            children: [
              // 【新增】智能提取按钮
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _isExtracting ? null : () => _handleExtract(context, provider),
                  icon: _isExtracting
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome, size: 18),
                  label: Text(_isExtracting ? '提取中...' : '提取角色'),
                  style: FilledButton.styleFrom(
                    backgroundColor: theme.colorScheme.secondaryContainer,
                    foregroundColor: theme.colorScheme.onSecondaryContainer,
                  ),
                ),
              ),
              const SizedBox(width: 8),

              IconButton.outlined(
                onPressed: () => _showCreateGroupDialog(context, provider),
                icon: const Icon(Icons.create_new_folder_outlined, size: 20),
                tooltip: '新建组',
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: () => _showCharacterDialog(context, provider, isEdit: false),
                icon: const Icon(Icons.person_add_alt_1, size: 20),
                tooltip: '新建角色',
              ),
            ],
          ),
        ),
      ],
    );
  }

  // AI 提取处理函数
  Future<void> _handleExtract(BuildContext context, WritingProvider provider) async {
    final aiProvider = context.read<AiProvider>();
    if (aiProvider.config.apiKey.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先在设置中配置 AI API Key')));
      return;
    }

    setState(() => _isExtracting = true);
    try {
      final result = await provider.syncCharactersFromChapter(aiProvider.config);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result), backgroundColor: Colors.green));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('提取失败: $e'), backgroundColor: Colors.red));
      }
    } finally {
      if (mounted) setState(() => _isExtracting = false);
    }
  }

  // --- 分组组件 ---
  Widget _buildGroupItem(
      BuildContext context,
      WritingProvider provider,
      CharacterGroup group,
      int groupIndex,
      ) {
    final theme = Theme.of(context);
    return DragTarget<Map<String, int?>>(
      onWillAccept: (data) => data?['groupIndex'] != groupIndex,
      onAccept: (data) {
        provider.moveCharacter(
          fromIndex: data['index']!,
          fromGroupIndex: data['groupIndex'],
          toGroupIndex: groupIndex,
        );
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('移动成功'), duration: Duration(milliseconds: 500)));
      },
      builder: (context, candidateData, rejectedData) {
        final isHovering = candidateData.isNotEmpty;
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: isHovering ? theme.colorScheme.primaryContainer.withOpacity(0.3) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: isHovering ? Border.all(color: theme.colorScheme.primary) : null,
          ),
          child: ExpansionTile(
            leading: Icon(Icons.folder_shared, color: theme.colorScheme.secondary),
            title: Text(group.title ?? '未命名分组'),
            shape: const Border(),
            collapsedShape: const Border(),
            trailing: _buildMoreMenu(
              context,
              onEdit: () => _showRenameGroupDialog(context, provider, groupIndex, group.title ?? ''),
              onDelete: () => _confirmDeleteGroup(context, provider, groupIndex, group.safeCharacters.isNotEmpty),
            ),
            children: List.generate(group.safeCharacters.length, (index) {
              final character = group.safeCharacters[index];
              return _buildDraggableCharacterItem(
                  context,
                  provider,
                  character,
                  index,
                  groupIndex
              );
            }),
          ),
        );
      },
    );
  }

  // --- 角色单体组件 (支持拖拽) ---
  Widget _buildDraggableCharacterItem(
      BuildContext context,
      WritingProvider provider,
      Character character,
      int index,
      int? groupIndex,
      ) {
    final dragData = {'index': index, 'groupIndex': groupIndex};

    final childWidget = CharacterCard(
      character: character,
      onTap: () {
        // 【关键修复】获取当前的 Provider 实例，传递给新路由
        // 这里的 context 是 CharacterView 的 context，它能找到 WritingProvider
        final currentWritingProvider = context.read<WritingProvider>();

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChangeNotifierProvider.value(
              value: currentWritingProvider, // 传递现有实例
              child: CharacterProfilePage(
                character: character,
                index: index,
                groupIndex: groupIndex,
              ),
            ),
          ),
        );
      },
      onEdit: () => _showCharacterDialog(
          context,
          provider,
          isEdit: true,
          character: character,
          index: index,
          groupIndex: groupIndex
      ),
      onDelete: () => provider.deleteCharacter(index, groupIndex: groupIndex),
    );

    // 外层包裹拖拽逻辑
    return LongPressDraggable<Map<String, int?>>(
      data: dragData,
      feedback: Material(
        color: Colors.transparent,
        child: Opacity(
            opacity: 0.8,
            child: SizedBox(
              width: 280,
              child: childWidget,
            )
        ),
      ),
      childWhenDragging: Opacity(opacity: 0.3, child: childWidget),
      child: childWidget,
    );
  }

  Widget _buildMoreMenu(BuildContext context, {required VoidCallback onEdit, required VoidCallback onDelete}) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.more_vert, size: 18, color: Colors.grey),
      onSelected: (v) {
        if (v == 'edit') onEdit();
        if (v == 'delete') onDelete();
      },
      itemBuilder: (context) => [
        const PopupMenuItem(value: 'edit', child: Row(children: [Icon(Icons.edit, size: 16), SizedBox(width: 8), Text('编辑')])),
        const PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete, size: 16, color: Colors.red), SizedBox(width: 8), Text('删除', style: TextStyle(color: Colors.red))])),
      ],
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.outline)),
    );
  }

  // ===================== 弹窗逻辑 =====================

  void _showCharacterDialog(
      BuildContext context,
      WritingProvider provider,
      {required bool isEdit, Character? character, int? index, int? groupIndex}
      ) {
    showDialog(
      context: context,
      builder: (_) => _CharacterEditDialog(
        isEdit: isEdit,
        originalCharacter: character,
        onSave: (name, desc, path) async {
          if (isEdit) {
            provider.updateCharacter(
                index!,
                groupIndex: groupIndex,
                newName: name,
                newDesc: desc,
                newAvatarPath: path
            );
          } else {
            // 先创建角色
            await provider.createCharacter(name: name, desc: desc);

            // 如果有图片，再更新进去 (解决新建角色无图的问题)
            if (path != null) {
              final characters = provider.book.characters;
              if (characters != null && characters.isNotEmpty) {
                final newIndex = characters.length - 1;
                provider.updateCharacter(
                    newIndex,
                    groupIndex: null,
                    newAvatarPath: path
                );
              }
            }
          }
        },
      ),
    );
  }

  void _showCreateGroupDialog(BuildContext context, WritingProvider provider) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('新建分组'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: '例如：主角团')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                provider.createCharacterGroup(controller.text);
                Navigator.pop(context);
              }
            },
            child: const Text('创建'),
          ),
        ],
      ),
    );
  }

  void _showRenameGroupDialog(BuildContext context, WritingProvider provider, int index, String oldName) {
    final controller = TextEditingController(text: oldName);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('重命名分组'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                provider.renameCharacterGroup(index, controller.text);
                Navigator.pop(context);
              }
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteGroup(BuildContext context, WritingProvider provider, int index, bool hasContent) {
    if (!hasContent) {
      provider.deleteCharacterGroup(index);
      return;
    }
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('删除分组？'),
        content: const Text('删除分组将一并删除组内角色，是否继续？', style: TextStyle(color: Colors.red)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              provider.deleteCharacterGroup(index);
              Navigator.pop(context);
            },
            child: const Text('删除'),
          ),
        ],
      ),
    );
  }
}

// 独立的弹窗组件
class _CharacterEditDialog extends StatefulWidget {
  final bool isEdit;
  final Character? originalCharacter;
  final Function(String name, String desc, String? path) onSave;

  const _CharacterEditDialog({required this.isEdit, this.originalCharacter, required this.onSave});

  @override
  State<_CharacterEditDialog> createState() => _CharacterEditDialogState();
}

class _CharacterEditDialogState extends State<_CharacterEditDialog> {
  late TextEditingController _nameCtrl;
  late TextEditingController _descCtrl;
  String? _avatarPath;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.originalCharacter?.name ?? '');
    _descCtrl = TextEditingController(text: widget.originalCharacter?.description ?? '');
    _avatarPath = widget.originalCharacter?.avatarPath;
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final croppedFile = await ImageCropper().cropImage(
        sourcePath: image.path,
        aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: '裁切头像',
            toolbarColor: Colors.deepPurple,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.square,
            lockAspectRatio: true,
          ),
          IOSUiSettings(title: '裁切头像', aspectRatioLockEnabled: true),
        ],
      );
      if (croppedFile != null) {
        setState(() => _avatarPath = croppedFile.path);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.isEdit ? '编辑角色' : '新建角色'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 40,
                backgroundImage: _avatarPath != null ? FileImage(File(_avatarPath!)) : null,
                child: _avatarPath == null ? const Icon(Icons.add_a_photo, size: 30) : null,
              ),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI 绘图引擎接入中...')));
              },
              icon: const Icon(Icons.auto_awesome, size: 16),
              label: const Text('AI 生成头像'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: '角色名称', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descCtrl,
              decoration: const InputDecoration(labelText: '一句话简介', border: OutlineInputBorder()),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
        FilledButton(
          onPressed: () {
            if (_nameCtrl.text.isNotEmpty) {
              widget.onSave(_nameCtrl.text, _descCtrl.text, _avatarPath);
              Navigator.pop(context);
            }
          },
          child: const Text('保存'),
        ),
      ],
    );
  }
}
