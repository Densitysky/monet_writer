
import 'package:flutter/material.dart';

class RootView extends StatelessWidget {
  final Function(String key, String title) onNavigate;

  const RootView({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildItem(
          context,
          icon: Icons.account_circle_outlined,
          title: '角色卡片',
          onTap: () => onNavigate('character', '角色卡片'),
        ),
        _buildItem(
          context,
          icon: Icons.auto_stories_outlined,
          title: '大纲梳理',
          onTap: () => onNavigate('outline', '大纲梳理'),
        ),
        _buildItem(
          context,
          icon: Icons.format_size,
          title: '排版设置',
          onTap: () => onNavigate('settings', '排版设置'),
        ),
      ],
    );
  }

  Widget _buildItem(BuildContext context, {required IconData icon, required String title, required VoidCallback onTap}) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.5),
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: theme.colorScheme.primary),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }
}
