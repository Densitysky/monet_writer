
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:monet_writer/providers/writing_provider.dart';
import 'package:monet_writer/models/custom_outline.dart';
import 'package:monet_writer/models/outline_tab.dart';
import 'package:monet_writer/models/outline_node.dart';
import 'package:monet_writer/services/ai_service.dart'; // 【新增】

class OutlineView extends StatefulWidget {
  final bool isFullScreen;

  const OutlineView({super.key, this.isFullScreen = false});

  @override
  State<OutlineView> createState() => _OutlineViewState();
}

class _OutlineViewState extends State<OutlineView> with SingleTickerProviderStateMixin {
  late TabController _mainTabController;

  int _selectedMacroIndex = 0;
  final _descCtrl = TextEditingController();
  final _outlineCtrl = TextEditingController();
  final _customTextCtrl = TextEditingController();

  bool _isDirty = false;
  bool _isAiLoading = false; // 【新增】AI Loading 状态

  @override
  void initState() {
    super.initState();
    _mainTabController = TabController(length: 2, vsync: this);

    _mainTabController.addListener(() {
      if (_mainTabController.indexIsChanging) _saveAll();
      // 切换 Tab 时刷新 UI 以显示/隐藏 FAB
      setState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadData();
    });
  }

  void _loadData() {
    if (!mounted) return;
    final book = context.read<WritingProvider>().book;
    _descCtrl.text = book.description ?? '';
    _outlineCtrl.text = book.outline ?? '';
    _loadCustomTabContent();
  }

  void _loadCustomTabContent() {
    final provider = context.read<WritingProvider>();
    final tabs = provider.book.settingsTabs ?? [];
    if (_selectedMacroIndex > 0 && (_selectedMacroIndex - 1) < tabs.length) {
      final tab = tabs[_selectedMacroIndex - 1];
      if (tab.type == OutlineType.text) {
        _customTextCtrl.text = tab.textContent ?? '';
      }
    }
  }

  @override
  void dispose() {
    _saveAll();
    _mainTabController.dispose();
    _descCtrl.dispose();
    _outlineCtrl.dispose();
    _customTextCtrl.dispose();
    super.dispose();
  }

  void _saveAll() {
    if (!_isDirty) return;
    final provider = context.read<WritingProvider>();

    provider.updateCoreOutline(_descCtrl.text, _outlineCtrl.text);

    final tabs = provider.book.settingsTabs ?? [];
    if (_selectedMacroIndex > 0 && (_selectedMacroIndex - 1) < tabs.length) {
      final tab = tabs[_selectedMacroIndex - 1];
      if (tab.type == OutlineType.text) {
        provider.updateTabContent(_selectedMacroIndex - 1, _customTextCtrl.text);
      }
    }

    setState(() => _isDirty = false);
  }

  // --- AI 逻辑处理 ---
  Future<void> _handleAiAction() async {
    final aiConfig = context.read<AiProvider>().config;
    if (aiConfig.apiKey.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先配置 AI API Key')));
      return;
    }

    setState(() => _isAiLoading = true);
    final provider = context.read<WritingProvider>();

    try {
      // 场景 1: 剧情·细纲 (List Mode) -> 生成节点
      // 场景 2: 宏观·设定 (Text Mode) -> 补全设定
      // 判断当前在哪个 Tab

      if (_mainTabController.index == 1) {
        // --- 剧情 Tab ---
        final result = await provider.generateOutlineNodeFromChapter(aiConfig);
        if (result != null) {
          // 添加到列表
          provider.addPlotNode(result['title']!, result['content']!);
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('剧情节点已生成'), backgroundColor: Colors.green));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('未能生成内容，请检查正文是否为空')));
        }
      } else {
        // --- 宏观 Tab ---
        // 判断当前是 Text 还是 List
        final tabs = provider.book.settingsTabs ?? [];
        bool isTextMode = false;
        TextEditingController? targetCtrl;

        if (_selectedMacroIndex == 0) {
          // 核心视图，暂不支持 AI (或者可以支持填充 outlineCtrl)
          // 假设这里我们只想让 AI 填充 "世界观与总纲" (_outlineCtrl)
          isTextMode = true;
          targetCtrl = _outlineCtrl;
        } else if ((_selectedMacroIndex - 1) < tabs.length) {
          final tab = tabs[_selectedMacroIndex - 1];
          if (tab.type == OutlineType.text) {
            isTextMode = true;
            targetCtrl = _customTextCtrl;
          }
        }

        if (isTextMode && targetCtrl != null) {
          final result = await provider.generateWorldSetting(aiConfig, targetCtrl.text);
          if (result != null) {
            // 追加内容
            targetCtrl.text = "${targetCtrl.text}\n\n$result";
            _isDirty = true;
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('设定已补全'), backgroundColor: Colors.green));
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('列表型设定集暂不支持自动生成')));
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('AI 错误: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _isAiLoading = false);
    }
  }

  void _toggleFullScreen() {
    if (widget.isFullScreen) {
      Navigator.pop(context);
    } else {
      Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const Scaffold(
          body: SafeArea(child: OutlineView(isFullScreen: true)),
        )),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final provider = context.watch<WritingProvider>();

    return Scaffold( // 嵌套 Scaffold 以支持 FAB
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          // --- 1. 顶部主导航 ---
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: theme.colorScheme.surface,
            child: Row(
              children: [
                if (widget.isFullScreen)
                  IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),

                Expanded(
                  child: Container(
                    height: 40,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: TabBar(
                      controller: _mainTabController,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicator: BoxDecoration(
                        color: theme.colorScheme.primary,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      labelColor: Colors.white,
                      unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
                      dividerColor: Colors.transparent,
                      tabs: const [Tab(text: '宏观 · 设定'), Tab(text: '剧情 · 细纲')],
                    ),
                  ),
                ),

                const SizedBox(width: 8),
                IconButton(
                  icon: Icon(widget.isFullScreen ? Icons.close_fullscreen : Icons.open_in_full),
                  tooltip: widget.isFullScreen ? '退出全屏' : '全屏编辑',
                  onPressed: _toggleFullScreen,
                )
              ],
            ),
          ),

          // --- 2. 内容区域 ---
          Expanded(
            child: TabBarView(
              controller: _mainTabController,
              children: [
                _buildMacroPage(context, provider, theme),
                _buildPlotPage(context, provider, theme),
              ],
            ),
          ),
        ],
      ),
      // 【新增】AI 悬浮按钮
      floatingActionButton: _isAiLoading
          ? FloatingActionButton.small(
        onPressed: null,
        backgroundColor: theme.colorScheme.surfaceContainerHighest,
        child: const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
      )
          : FloatingActionButton.small(
        onPressed: _handleAiAction,
        tooltip: 'AI 自动生成/补全',
        backgroundColor: theme.colorScheme.primaryContainer,
        child: const Icon(Icons.auto_awesome),
      ),
    );
  }

  // ==================== Page 1: 宏观 · 设定 (Macro) ====================

  Widget _buildMacroPage(BuildContext context, WritingProvider provider, ThemeData theme) {
    final tabs = provider.book.settingsTabs ?? [];

    return Column(
      children: [
        // A. 二级导航条
        Container(
          height: 50,
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: theme.dividerColor.withOpacity(0.5))),
          ),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => _showAllTabsMenu(context, provider, tabs),
                tooltip: '查看所有设定',
              ),
              VerticalDivider(width: 1, indent: 10, endIndent: 10, color: theme.dividerColor),

              Expanded(
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  children: [
                    _buildChip(0, '核心', Icons.dashboard, theme),
                    ...List.generate(tabs.length, (index) {
                      final tab = tabs[index];
                      return GestureDetector(
                        onLongPress: () => _showTabMenu(context, provider, index, tab),
                        child: _buildChip(
                            index + 1,
                            tab.title ?? '未命名',
                            tab.type == OutlineType.text ? Icons.description : Icons.list_alt,
                            theme
                        ),
                      );
                    }),

                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: IconButton.filledTonal(
                        icon: const Icon(Icons.add, size: 18),
                        onPressed: () => _showCreateTabDialog(context, provider),
                        style: IconButton.styleFrom(
                            visualDensity: VisualDensity.compact,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        Expanded(
          child: _selectedMacroIndex == 0
              ? _buildCoreView(theme)
              : _buildCustomTabView(provider, tabs, theme),
        ),
      ],
    );
  }

  // 显示所有 Tab 的底部面板
  void _showAllTabsMenu(BuildContext context, WritingProvider provider, List<OutlineTab> tabs) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SizedBox(
        height: 300,
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text("切换设定集", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                childAspectRatio: 2.5,
                padding: const EdgeInsets.all(16),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  _buildGridItem(ctx, 0, '核心', Icons.dashboard, Colors.blue),
                  ...List.generate(tabs.length, (i) {
                    final tab = tabs[i];
                    return _buildGridItem(
                        ctx, i + 1, tab.title ?? '',
                        tab.type == OutlineType.text ? Icons.description : Icons.list_alt,
                        Colors.indigo
                    );
                  })
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGridItem(BuildContext ctx, int index, String label, IconData icon, Color color) {
    final isSelected = _selectedMacroIndex == index;
    return InkWell(
      onTap: () {
        Navigator.pop(ctx);
        _saveAll();
        setState(() {
          _selectedMacroIndex = index;
          _loadCustomTabContent();
        });
      },
      borderRadius: BorderRadius.circular(8),
      child: Container(
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.1) : Colors.transparent,
          border: Border.all(color: isSelected ? color : Colors.grey.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: isSelected ? color : Colors.grey),
            const SizedBox(width: 4),
            Flexible(child: Text(label, overflow: TextOverflow.ellipsis, style: TextStyle(color: isSelected ? color : Colors.black87))),
          ],
        ),
      ),
    );
  }

  Widget _buildChip(int index, String label, IconData icon, ThemeData theme) {
    final isSelected = _selectedMacroIndex == index;
    return Padding(
      padding: const EdgeInsets.only(right: 8, top: 8, bottom: 8),
      child: FilterChip(
        selected: isSelected,
        showCheckmark: false,
        avatar: Icon(icon, size: 16, color: isSelected ? theme.colorScheme.onPrimary : theme.colorScheme.primary),
        label: Text(label),
        onSelected: (_) {
          _saveAll();
          setState(() {
            _selectedMacroIndex = index;
            _loadCustomTabContent();
          });
        },
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  Widget _buildCoreView(ThemeData theme) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('核心梗概 (Logline)', style: TextStyle(color: theme.colorScheme.primary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: _descCtrl,
          maxLines: 3,
          decoration: _inputDeco(theme, '一句话讲清楚：谁？要干什么？阻碍是什么？'),
          onChanged: (_) => _isDirty = true,
        ),
        const SizedBox(height: 24),
        Text('世界观与总纲', style: TextStyle(color: theme.colorScheme.primary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: _outlineCtrl,
          maxLines: null,
          minLines: 10,
          decoration: _inputDeco(theme, '在此书写完整的故事大纲、结局规划、体系设定...'),
          onChanged: (_) => _isDirty = true,
        ),
        // 底部留白给 FAB
        const SizedBox(height: 60),
      ],
    );
  }

  Widget _buildCustomTabView(WritingProvider provider, List<OutlineTab> tabs, ThemeData theme) {
    if ((_selectedMacroIndex - 1) >= tabs.length) return const SizedBox();

    final tabIndex = _selectedMacroIndex - 1;
    final tab = tabs[tabIndex];

    if (tab.type == OutlineType.text) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: _customTextCtrl,
          maxLines: null,
          expands: true,
          textAlignVertical: TextAlignVertical.top,
          style: const TextStyle(fontSize: 16, height: 1.6),
          decoration: _inputDeco(theme, '在此记录${tab.title}的详细设定...'),
          onChanged: (_) => _isDirty = true,
        ),
      );
    }

    return _buildNodeList(
      context,
      theme,
      nodes: tab.nodes ?? [],
      onReorder: (oldIdx, newIdx) => provider.reorderNodesInTab(tabIndex, oldIdx, newIdx),
      onAdd: () => _showNodeDialog(context, (t, c) => provider.addNodeToTab(tabIndex, t, c)),
      onEdit: (node, nodeIdx) => _showNodeDialog(context, (t, c) => provider.updateNodeInTab(tabIndex, nodeIdx, t, c), node: node),
      onDelete: (nodeIdx) => provider.deleteNodeInTab(tabIndex, nodeIdx),
    );
  }

  Widget _buildPlotPage(BuildContext context, WritingProvider provider, ThemeData theme) {
    final nodes = provider.book.customOutlines ?? [];

    return _buildNodeList(
      context,
      theme,
      nodes: nodes,
      isLegacy: true,
      onReorder: provider.reorderPlotNodes,
      onAdd: () => _showNodeDialog(context, provider.addPlotNode),
      onEdit: (node, index) => _showNodeDialog(context, (t, c) => provider.updatePlotNode(index, t, c), legacyNode: node as CustomOutline),
      onDelete: provider.deletePlotNode,
    );
  }

  InputDecoration _inputDeco(ThemeData theme, String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: theme.colorScheme.surfaceContainerLow,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.all(16),
    );
  }

  // 通用节点列表构建器
  Widget _buildNodeList(
      BuildContext context,
      ThemeData theme,
      {
        required List<dynamic> nodes,
        required Function(int, int) onReorder,
        required VoidCallback onAdd,
        required Function(dynamic, int) onEdit,
        required Function(int) onDelete,
        bool isLegacy = false,
      }
      ) {
    if (nodes.isEmpty) {
      return Center(
        child: GestureDetector(
          onTap: onAdd,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomPaint(
                size: const Size(2, 60),
                painter: _DashedLinePainter(color: theme.colorScheme.outlineVariant),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.add, size: 32, color: theme.colorScheme.primary),
              ),
              const SizedBox(height: 16),
              const Text('点击添加第一个事件节点', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text('开始梳理你的故事脉络', style: TextStyle(color: theme.colorScheme.outline, fontSize: 12)),
              const SizedBox(height: 16),
              CustomPaint(
                size: const Size(2, 60),
                painter: _DashedLinePainter(color: theme.colorScheme.outlineVariant),
              ),
            ],
          ),
        ),
      );
    }

    return Stack(
      children: [
        ReorderableListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
          itemCount: nodes.length,
          onReorder: onReorder,
          proxyDecorator: (child, index, animation) => Material(color: Colors.transparent, child: child),
          itemBuilder: (context, index) {
            final node = nodes[index];
            final title = node.title ?? '未命名';
            final content = node.content ?? '';

            return Container(
              key: ValueKey(node.hashCode),
              margin: const EdgeInsets.only(bottom: 12),
              child: IntrinsicHeight(
                child: Row(
                  children: [
                    SizedBox(width: 20, child: Center(child: Container(width: 2, color: theme.dividerColor))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => onEdit(node, index),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surfaceContainerLow,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: theme.dividerColor.withOpacity(0.3)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
                                  InkWell(
                                    onTap: () => onDelete(index),
                                    child: Icon(Icons.close, size: 14, color: theme.colorScheme.outline),
                                  )
                                ],
                              ),
                              if (content.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(content, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: theme.colorScheme.onSurfaceVariant)),
                              ]
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        Positioned(
          right: 16, bottom: 16,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 60),
            child: FloatingActionButton.small(
                heroTag: 'manual_add',
                onPressed: onAdd,
                child: const Icon(Icons.add)
            ),
          ),
        ),
      ],
    );
  }

  void _showCreateTabDialog(BuildContext context, WritingProvider provider) {
    final ctrl = TextEditingController();
    OutlineType selectedType = OutlineType.text;
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('新建设定集'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(labelText: '名称', hintText: '例如: 魔法体系')),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: ChoiceChip(label: const Text('文本模式'), selected: selectedType == OutlineType.text, onSelected: (b) => setState(() => selectedType = OutlineType.text))),
                  const SizedBox(width: 8),
                  Expanded(child: ChoiceChip(label: const Text('列表模式'), selected: selectedType == OutlineType.list, onSelected: (b) => setState(() => selectedType = OutlineType.list))),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
            FilledButton(
              onPressed: () {
                if (ctrl.text.isNotEmpty) {
                  provider.createSettingsTab(ctrl.text, selectedType);
                  Navigator.pop(context);
                }
              },
              child: const Text('创建'),
            ),
          ],
        ),
      ),
    );
  }

  void _showTabMenu(BuildContext context, WritingProvider provider, int index, OutlineTab tab) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.edit), title: const Text('重命名'),
            onTap: () { Navigator.pop(ctx); _showRenameTabDialog(context, provider, index, tab.title ?? ''); },
          ),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.red), title: const Text('删除此设定集', style: TextStyle(color: Colors.red)),
            onTap: () {
              Navigator.pop(ctx);
              provider.deleteSettingsTab(index);
              if (_selectedMacroIndex == (index + 1)) setState(() => _selectedMacroIndex = 0);
            },
          ),
        ],
      ),
    );
  }

  void _showRenameTabDialog(BuildContext context, WritingProvider provider, int index, String oldName) {
    final ctrl = TextEditingController(text: oldName);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('重命名'),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(onPressed: () { if (ctrl.text.isNotEmpty) { provider.renameSettingsTab(index, ctrl.text); Navigator.pop(context); }}, child: const Text('确定')),
        ],
      ),
    );
  }

  void _showNodeDialog(BuildContext context, Function(String, String) onSave, {dynamic node, CustomOutline? legacyNode}) {
    final title = node?.title ?? legacyNode?.title ?? '';
    final content = node?.content ?? legacyNode?.content ?? '';
    final tCtrl = TextEditingController(text: title);
    final cCtrl = TextEditingController(text: content);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title.isEmpty ? '添加条目' : '编辑条目'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: tCtrl, autofocus: true, decoration: const InputDecoration(labelText: '标题')),
              const SizedBox(height: 12),
              TextField(controller: cCtrl, maxLines: 5, decoration: const InputDecoration(labelText: '内容详情')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(onPressed: () { if (tCtrl.text.isNotEmpty) { onSave(tCtrl.text, cCtrl.text); Navigator.pop(context); }}, child: const Text('保存')),
        ],
      ),
    );
  }
}

class _DashedLinePainter extends CustomPainter {
  final Color color;
  _DashedLinePainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..strokeWidth = 2..style = PaintingStyle.stroke;
    double startY = 0;
    while (startY < size.height) {
      canvas.drawLine(Offset(0, startY), Offset(0, startY + 5), paint);
      startY += 10;
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
