
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:monet_writer/providers/user_provider.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final settings = context.watch<UserProvider>();

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      children: [
        // 1. 主题选择
        Text('阅读主题', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SizedBox(
          height: 50,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: List.generate(UserProvider.themes.length, (index) {
              final item = UserProvider.themes[index];
              final isSelected = settings.themeIndex == index;
              return GestureDetector(
                onTap: () => settings.updateTheme(index),
                child: Container(
                  width: 50,
                  margin: const EdgeInsets.only(right: 12),
                  decoration: BoxDecoration(
                    color: item.backgroundColor,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isSelected ? theme.colorScheme.primary : Colors.black12,
                      width: isSelected ? 3 : 1,
                    ),
                    boxShadow: [
                      if (isSelected)
                        BoxShadow(color: theme.colorScheme.primary.withOpacity(0.3), blurRadius: 8),
                    ],
                  ),
                  child: isSelected
                      ? Icon(Icons.check, color: item.textColor, size: 20)
                      : null,
                ),
              );
            }),
          ),
        ),

        const SizedBox(height: 24),
        const Divider(),

        // 2. 个性化背景设置
        Text('个性化', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('背景毛玻璃效果'),
          subtitle: const Text('让文字在背景上更清晰'),
          value: settings.isBackgroundBlurred,
          onChanged: (val) => settings.toggleBackgroundBlur(val),
        ),
        // 【新增开关】控制是否使用头像
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('使用头像作为背景'),
          subtitle: const Text('若未单独设置背景图，则使用头像'),
          value: settings.useAvatarAsBackground,
          onChanged: (val) => settings.toggleUseAvatarAsBackground(val),
        ),

        const Divider(),

        // 3. 字体设置
        Text('字体设置', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: Text(
                '当前字体：${settings.fontFamily == "CustomFont" ? "自定义" : "系统默认"}',
                style: const TextStyle(fontSize: 14),
              ),
            ),
            if (settings.fontFamily == "CustomFont")
              TextButton(
                onPressed: settings.resetFont,
                child: const Text('重置'),
              ),
            FilledButton.tonal(
              onPressed: settings.loadLocalFont,
              child: const Text('导入字体'),
            ),
          ],
        ),

        const SizedBox(height: 16),
        Text('字号: ${settings.fontSize.toInt()}', style: theme.textTheme.bodyMedium),
        Slider(
          value: settings.fontSize,
          min: 12,
          max: 30,
          divisions: 18,
          label: settings.fontSize.toInt().toString(),
          onChanged: (v) => settings.updateWritingConfig(fontSize: v),
        ),

        Text('行高: ${settings.lineHeight.toStringAsFixed(1)}', style: theme.textTheme.bodyMedium),
        Slider(
          value: settings.lineHeight,
          min: 1.0,
          max: 3.0,
          divisions: 20,
          label: settings.lineHeight.toStringAsFixed(1),
          onChanged: (v) => settings.updateWritingConfig(lineHeight: v),
        ),
      ],
    );
  }
}
