
import 'package:flutter/material.dart';

/// 主题状态管理
/// 负责控制 App 的全局颜色种子和深色模式
class ThemeProvider extends ChangeNotifier {
  // 默认种子颜色 (靛青色)
  Color _seedColor = Colors.indigo;

  // 默认外观模式 (跟随系统)
  ThemeMode _themeMode = ThemeMode.system;

  Color get seedColor => _seedColor;
  ThemeMode get themeMode => _themeMode;

  /// 切换主题种子颜色
  void setSeedColor(Color color) {
    _seedColor = color;
    notifyListeners(); // 通知 UI 刷新
  }

  /// 切换外观模式 (浅色/深色/系统)
  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    notifyListeners();
  }
}
