
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import 'package:palette_generator/palette_generator.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:monet_writer/services/database_service.dart';

class WritingTheme {
  final String name;
  final Color backgroundColor;
  final Color textColor;
  final Color cursorColor;
  final Color outlineColor;

  const WritingTheme(this.name, this.backgroundColor, this.textColor, {this.cursorColor = Colors.blue, this.outlineColor = Colors.grey});
}

class UserProvider extends ChangeNotifier {
  // --- 核心数据 ---
  String _nickname = "莫纳书友";
  String? _avatarPath;
  String? _backgroundPath; // 自定义背景图

  // --- 开关 ---
  bool _useAvatarAsBackground = false;

  // --- 统计数据 ---
  int _totalWords = 0;
  int _todayWords = 0;
  int _consecutiveDays = 0;

  // --- 外观设置 ---
  bool _isBackgroundBlurred = true;
  double _fontSize = 18.0;
  double _lineHeight = 1.8;
  String _fontFamily = 'System';
  String? _customFontPath;
  int _themeIndex = 0;

  // 预设主题
  static const List<WritingTheme> themes = [
    WritingTheme('默认白', Color(0xFFFAFAFA), Colors.black87),
    WritingTheme('护眼绿', Color(0xFFE8F5E9), Color(0xFF2E7D32)),
    WritingTheme('羊皮纸', Color(0xFFFDF5E6), Color(0xFF5D4037)),
    WritingTheme('暗夜黑', Color(0xFF1E1E1E), Color(0xFFB0BEC5), cursorColor: Colors.white, outlineColor: Colors.grey),
    WritingTheme('深海蓝', Color(0xFF102027), Color(0xFFCFD8DC), cursorColor: Colors.cyan),
  ];

  // --- Getters ---
  String get nickname => _nickname;
  String? get avatarPath => _avatarPath;
  bool get useAvatarAsBackground => _useAvatarAsBackground;

  // 兼容 ProfilePage
  String? get backgroundPath => _backgroundPath;

  // 写作页使用的背景图逻辑
  String? get backgroundImagePath {
    // 1. 如果开启了开关且有头像，优先用头像
    if (_useAvatarAsBackground && _avatarPath != null && File(_avatarPath!).existsSync()) {
      return _avatarPath;
    }
    // 2. 如果有专门设置的背景图，用背景图
    if (_backgroundPath != null && File(_backgroundPath!).existsSync()) {
      return _backgroundPath;
    }
    // 3. 否则为空（纯色）
    return null;
  }

  int get totalWords => _totalWords;
  int get todayWords => _todayWords;
  int get consecutiveDays => _consecutiveDays;
  bool get isBackgroundBlurred => _isBackgroundBlurred;
  double get fontSize => _fontSize;
  double get lineHeight => _lineHeight;
  String get fontFamily => _fontFamily;
  int get themeIndex => _themeIndex;
  WritingTheme get currentTheme => themes[_themeIndex];

  PaletteGenerator? _paletteGenerator;
  Color get primaryColor => _paletteGenerator?.dominantColor?.color ?? Colors.blue;

  // --- 初始化 ---
  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();

    _nickname = prefs.getString('user_nickname') ?? "莫纳书友";
    _avatarPath = prefs.getString('user_avatar_path');
    _backgroundPath = prefs.getString('user_bg_path');
    _useAvatarAsBackground = prefs.getBool('setting_use_avatar_bg') ?? false;

    // 【核心修复】清理逻辑：如果背景路径跟头像路径一样，说明是旧版本残留，强制清除
    if (_backgroundPath == _avatarPath) {
      _backgroundPath = null;
    }

    await refreshStats();

    _isBackgroundBlurred = prefs.getBool('setting_bg_blur') ?? true;
    _fontSize = prefs.getDouble('setting_font_size') ?? 18.0;
    _lineHeight = prefs.getDouble('setting_line_height') ?? 1.8;
    _fontFamily = prefs.getString('setting_font_family') ?? 'System';
    _customFontPath = prefs.getString('setting_font_path');
    _themeIndex = prefs.getInt('setting_theme_index') ?? 0;

    if (_customFontPath != null && File(_customFontPath!).existsSync()) {
      await _loadFontToEngine(_customFontPath!);
    }

    if (_avatarPath != null) {
      await _updatePalette();
    }
    notifyListeners();
  }

  Future<void> refreshStats() async {
    final db = DatabaseService();
    _todayWords = await db.getTodayWordCount();
    _totalWords = await db.getTotalWordCount();
    _consecutiveDays = await db.getConsecutiveDays();
    notifyListeners();
  }

  // --- Setters ---

  Future<void> toggleUseAvatarAsBackground(bool val) async {
    _useAvatarAsBackground = val;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('setting_use_avatar_bg', val);
    notifyListeners();
  }

  Future<void> updateNickname(String name) async {
    _nickname = name;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_nickname', name);
    notifyListeners();
  }
  Future<void> setNickname(String name) => updateNickname(name);

  Future<void> updateWritingConfig({double? fontSize, double? lineHeight}) async {
    final prefs = await SharedPreferences.getInstance();
    if (fontSize != null) {
      _fontSize = fontSize;
      await prefs.setDouble('setting_font_size', fontSize);
    }
    if (lineHeight != null) {
      _lineHeight = lineHeight;
      await prefs.setDouble('setting_line_height', lineHeight);
    }
    notifyListeners();
  }
  Future<void> setFontSize(double size) => updateWritingConfig(fontSize: size);
  Future<void> setLineHeight(double height) => updateWritingConfig(lineHeight: height);

  Future<void> setFontFamily(String font) async {
    _fontFamily = font;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('setting_font_family', font);
    notifyListeners();
  }

  Future<void> resetFont() async {
    await setFontFamily('System');
    _customFontPath = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('setting_font_path');
    notifyListeners();
  }

  Future<void> loadLocalFont() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['ttf', 'otf'],
      );

      if (result != null) {
        File file = File(result.files.single.path!);
        final directory = await getApplicationDocumentsDirectory();
        final savedFile = await file.copy('${directory.path}/custom_font${p.extension(file.path)}');

        _customFontPath = savedFile.path;
        await _loadFontToEngine(_customFontPath!);

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('setting_font_path', _customFontPath!);
        await setFontFamily('CustomFont');
      }
    } catch (e) {
      debugPrint("字体导入失败: $e");
    }
  }

  Future<void> updateTheme(int index) async {
    if (index >= 0 && index < themes.length) {
      _themeIndex = index;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('setting_theme_index', index);
      notifyListeners();
    }
  }

  Future<void> toggleBackgroundBlur(bool val) async {
    _isBackgroundBlurred = val;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('setting_bg_blur', val);
    notifyListeners();
  }

  Future<void> setBackgroundImage(String? path) async {
    _backgroundPath = path;
    final prefs = await SharedPreferences.getInstance();
    if (path == null) {
      await prefs.remove('user_bg_path');
    } else {
      await prefs.setString('user_bg_path', path);
    }
    notifyListeners();
  }

  Future<void> _loadFontToEngine(String path) async {
    try {
      File file = File(path);
      var fontData = await file.readAsBytes();
      String fontName = 'CustomFont';
      var fontLoader = FontLoader(fontName);
      fontLoader.addFont(Future.value(ByteData.view(fontData.buffer)));
      await fontLoader.load();
      _fontFamily = fontName;
    } catch (e) {
      debugPrint("注册字体失败: $e");
    }
  }

  Future<void> updateAvatarPath(String path) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final savedFile = await File(path).copy('${directory.path}/avatar_$timestamp.jpg');
      _avatarPath = savedFile.path;
      // 这里不再自动设置 backgroundPath，防止干扰开关

      await _updatePalette();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_avatar_path', _avatarPath!);
      notifyListeners();
    } catch (e) {
      debugPrint("头像保存失败: $e");
    }
  }

  Future<void> _updatePalette() async {
    if (_avatarPath == null) return;
    try {
      _paletteGenerator = await PaletteGenerator.fromImageProvider(
        FileImage(File(_avatarPath!)),
        maximumColorCount: 20,
      );
    } catch (e) {
      debugPrint("调色板生成失败: $e");
    }
  }
}
