
import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:monet_writer/models/book.dart';
import 'package:monet_writer/models/chapter.dart';
import 'package:monet_writer/models/prompt_template.dart';
import 'package:monet_writer/models/daily_stats.dart';
import 'package:monet_writer/models/ai_config.dart';
import 'package:intl/intl.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  late Isar _isar;
  Isar get isar => _isar;

  /// 初始化数据库
  Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    _isar = await Isar.open(
      [
        BookSchema,
        ChapterSchema,
        PromptTemplateSchema,
        DailyStatsSchema,
        AiConfigSchema,
      ],
      directory: dir.path,
    );
  }

  // ==================== 数据统计核心逻辑 (已升级) ====================

  /// 更新今日码字统计 (升级版：支持记录具体章节)
  /// [delta] 变化的字数
  /// [bookTitle] 书名
  /// [chapterTitle] 章节名
  Future<void> updateDailyStats(int delta, String bookTitle, String chapterTitle) async {
    if (delta == 0) return;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final timeStr = DateFormat('HH:mm').format(now);

    await _isar.writeTxn(() async {
      DailyStats? stats = await _isar.dailyStats
          .filter()
          .dateEqualTo(today)
          .findFirst();

      if (stats == null) {
        // 新建当天的统计
        stats = DailyStats()
          ..date = today
          ..wordCount = delta > 0 ? delta : 0
          ..updatedAt = now
          ..logs = [
            DailyLog()
              ..timeStr = timeStr
              ..bookTitle = bookTitle
              ..chapterTitle = chapterTitle
              ..wordCountChange = delta
          ];
      } else {
        // 更新当天总字数
        stats.wordCount += delta;
        if (stats.wordCount < 0) stats.wordCount = 0;
        stats.updatedAt = now;

        // 更新日志列表 (合并同章节记录)
        List<DailyLog> currentLogs = stats.logs.toList();

        final existingLogIndex = currentLogs.indexWhere(
                (log) => log.bookTitle == bookTitle && log.chapterTitle == chapterTitle
        );

        if (existingLogIndex != -1) {
          // 更新已有记录
          final log = currentLogs[existingLogIndex];
          log.wordCountChange += delta;
          log.timeStr = timeStr; // 更新为最新操作时间
          currentLogs[existingLogIndex] = log;
        } else {
          // 新增一条记录
          currentLogs.insert(0, DailyLog() // 插到最前面
            ..timeStr = timeStr
            ..bookTitle = bookTitle
            ..chapterTitle = chapterTitle
            ..wordCountChange = delta
          );
        }
        stats.logs = currentLogs;
      }

      await _isar.dailyStats.put(stats);
    });
  }

  // --- 统计查询方法 (保留完整逻辑) ---

  Future<int> getTodayWordCount() async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final stats = await _isar.dailyStats.filter().dateEqualTo(today).findFirst();
    return stats?.wordCount ?? 0;
  }

  Future<int> getTotalWordCount() async {
    return await _isar.books.filter().isDeletedEqualTo(false).wordCountProperty().sum();
  }

  Future<int> getConsecutiveDays() async {
    final statsList = await _isar.dailyStats.filter().wordCountGreaterThan(0).sortByDateDesc().findAll();
    if (statsList.isEmpty) return 0;
    int streak = 0;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final latestDate = statsList.first.date;
    if (today.difference(latestDate).inDays > 1) return 0;

    DateTime checkDate = today;
    if (!statsList.any((s) => s.date.isAtSameMomentAs(today))) {
      checkDate = today.subtract(const Duration(days: 1));
    }
    final activeDays = statsList.map((e) => e.date).toSet();
    if (activeDays.contains(checkDate)) {
      streak++;
      for (int d = 1; d < 3650; d++) {
        if (activeDays.contains(checkDate.subtract(Duration(days: d)))) streak++; else break;
      }
    }
    return streak;
  }

  Future<List<DailyStats>> getWeeklyStats() async {
    final today = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
    return await _isar.dailyStats.filter().dateGreaterThan(today.subtract(const Duration(days: 7))).sortByDate().findAll();
  }

  Future<DailyStats?> getPeakRecord() async => await _isar.dailyStats.where().sortByWordCountDesc().findFirst();

  Future<int> getActiveDaysCount() async => await _isar.dailyStats.filter().wordCountGreaterThan(0).count();

  Future<List<DailyStats>> getMonthlyStats(DateTime month) async {
    final start = DateTime(month.year, month.month, 1);
    final end = DateTime(month.year, month.month + 1, 1).subtract(const Duration(seconds: 1));
    return await _isar.dailyStats.filter().dateBetween(start, end).sortByDate().findAll();
  }

  Future<List<DailyStats>> getCurrentMonthStats() async => getMonthlyStats(DateTime.now());

  // ==================== 书籍与章节基础操作 (已补全) ====================

  Future<void> createBook(String title, {String? desc, String? coverPath}) async {
    final newBook = Book()
      ..title = title
      ..description = desc
      ..coverPath = coverPath
      ..createdAt = DateTime.now()
      ..updatedAt = DateTime.now();

    await _isar.writeTxn(() async {
      await _isar.books.put(newBook);
    });
  }

  Future<List<Book>> getAllBooks() async {
    return await _isar.books
        .filter()
        .isDeletedEqualTo(false)
        .sortByUpdatedAtDesc()
        .findAll();
  }

  Stream<List<Book>> watchDeletedBooks() {
    return _isar.books
        .filter()
        .isDeletedEqualTo(true)
        .sortByUpdatedAtDesc()
        .watch(fireImmediately: true);
  }

  Future<void> restoreBook(int bookId) async {
    await _isar.writeTxn(() async {
      final book = await _isar.books.get(bookId);
      if (book != null) {
        book.isDeleted = false;
        book.updatedAt = DateTime.now();
        await _isar.books.put(book);
      }
    });
  }

  Future<void> deleteBookPermanently(int bookId) async {
    await _isar.writeTxn(() async {
      // 级联删除章节
      await _isar.chapters.filter().bookIdEqualTo(bookId).deleteAll();
      // 删除书籍
      await _isar.books.delete(bookId);
    });
  }

  Future<List<Chapter>> getChaptersForBook(int bookId) async {
    return await _isar.chapters
        .filter()
        .bookIdEqualTo(bookId)
        .sortByOrderIndex()
        .findAll();
  }

  Future<void> createChapter(int bookId, String title) async {
    await _isar.writeTxn(() async {
      final count = await _isar.chapters.filter().bookIdEqualTo(bookId).count();

      final newChapter = Chapter()
        ..bookId = bookId
        ..title = title
        ..content = ''
        ..orderIndex = count
        ..updatedAt = DateTime.now();

      await _isar.chapters.put(newChapter);

      // 更新书籍时间
      final book = await _isar.books.get(bookId);
      if (book != null) {
        book.updatedAt = DateTime.now();
        await _isar.books.put(book);
      }
    });
  }

  Future<void> updateChapterContent(int chapterId, String content, int wordCount) async {
    await _isar.writeTxn(() async {
      final chapter = await _isar.chapters.get(chapterId);
      if (chapter != null) {
        chapter.content = content;
        chapter.wordCount = wordCount;
        chapter.updatedAt = DateTime.now();
        await _isar.chapters.put(chapter);
      }
    });
  }

  // ==================== AI 配置管理 (新增) ====================

  /// 获取所有 AI 配置
  Future<List<AiConfig>> getAllAiConfigs() async {
    return await _isar.aiConfigs.where().findAll();
  }

  /// 保存或更新 AI 配置
  Future<void> saveAiConfig(AiConfig config) async {
    await _isar.writeTxn(() async {
      await _isar.aiConfigs.put(config);
    });
  }

  /// 删除 AI 配置
  Future<void> deleteAiConfig(int id) async {
    await _isar.writeTxn(() async {
      await _isar.aiConfigs.delete(id);
    });
  }
}
