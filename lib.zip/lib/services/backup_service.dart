
import 'dart:convert';
import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:flutter/material.dart';
import 'package:isar/isar.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:monet_writer/services/database_service.dart';
import 'package:monet_writer/models/book.dart';
import 'package:monet_writer/models/chapter.dart';
import 'package:monet_writer/models/character.dart';
import 'package:monet_writer/models/daily_stats.dart';
import 'package:monet_writer/models/prompt_template.dart';

class BackupService {
  static final BackupService _instance = BackupService._internal();
  factory BackupService() => _instance;
  BackupService._internal();

  final Isar _isar = DatabaseService().isar;

  /// 1. 创建全量备份
  Future<void> createBackup(BuildContext context) async {
    try {
      // 获取临时目录用于打包
      final tempDir = await getTemporaryDirectory();
      final backupWorkDir = Directory('${tempDir.path}/monet_backup_work');
      if (backupWorkDir.existsSync()) backupWorkDir.deleteSync(recursive: true);
      backupWorkDir.createSync();

      final assetsDir = Directory('${backupWorkDir.path}/assets');
      assetsDir.createSync();

      // --- A. 导出数据 ---
      final Map<String, dynamic> fullData = {};

      // 1. 书籍 & 封面处理
      final booksJson = await _isar.books.where().exportJson();
      for (var item in booksJson) {
        if (item['coverPath'] != null) {
          final String originalPath = item['coverPath'];
          final String fileName = p.basename(originalPath);
          await _copyAssetToBackup(originalPath, fileName, assetsDir);
          item['coverPath'] = fileName; // 存相对路径
        }
      }
      fullData['books'] = booksJson;

      // 2. 章节
      fullData['chapters'] = await _isar.chapters.where().exportJson();

      // 3. 统计数据
      fullData['daily_stats'] = await _isar.dailyStats.where().exportJson();

      // 4. 提示词模板
      fullData['prompts'] = await _isar.promptTemplates.where().exportJson();

      // 5. 角色头像处理 (目前 Character 嵌套在 Book 里，Isar 导出 JSON 会包含嵌套对象吗？)
      // Isar 的 exportJson 对于 Embedded 对象会直接导出。
      // 但对于 Links (如果有)，可能只导出 ID。我们的 Character 是 Embedded 在 Book 里的吗？
      // 回顾模型：Book -> characters (List<Character>)。是的，是 Embedded。
      // 所以我们需要遍历 booksJson 里的 characters 列表来处理头像。
      for (var bookMap in booksJson) {
        if (bookMap['characters'] != null) {
          final List chars = bookMap['characters'];
          for (var charMap in chars) {
            if (charMap['avatarPath'] != null) {
              final String originalPath = charMap['avatarPath'];
              final String fileName = p.basename(originalPath);
              await _copyAssetToBackup(originalPath, fileName, assetsDir);
              charMap['avatarPath'] = fileName;
            }
          }
        }
        // 同理处理 characterGroups
        if (bookMap['characterGroups'] != null) {
          final List groups = bookMap['characterGroups'];
          for (var groupMap in groups) {
            if (groupMap['characters'] != null) {
              final List chars = groupMap['characters'];
              for (var charMap in chars) {
                if (charMap['avatarPath'] != null) {
                  final String originalPath = charMap['avatarPath'];
                  final String fileName = p.basename(originalPath);
                  await _copyAssetToBackup(originalPath, fileName, assetsDir);
                  charMap['avatarPath'] = fileName;
                }
              }
            }
          }
        }
      }

      // --- B. 写入 JSON ---
      final jsonFile = File('${backupWorkDir.path}/data.json');
      await jsonFile.writeAsString(jsonEncode(fullData));

      // --- C. 压缩 ZIP ---
      final encoder = ZipFileEncoder();
      final zipPath = '${tempDir.path}/monet_backup_${DateTime.now().millisecondsSinceEpoch}.zip';
      encoder.create(zipPath);
      encoder.addDirectory(backupWorkDir, includeDirName: false); // 不包含顶层文件夹名
      encoder.close();

      // --- D. 分享/导出 ---
      final xFile = XFile(zipPath);
      await Share.shareXFiles([xFile], text: '落笔数据备份');

      // 清理
      // backupWorkDir.deleteSync(recursive: true); // 异步清理可选

    } catch (e) {
      debugPrint('Backup failed: $e');
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('备份失败: $e')));
      }
      rethrow;
    }
  }

  /// 辅助：复制文件到备份目录
  Future<void> _copyAssetToBackup(String originalPath, String fileName, Directory assetsDir) async {
    final file = File(originalPath);
    if (await file.exists()) {
      await file.copy('${assetsDir.path}/$fileName');
    }
  }

  /// 2. 恢复备份
  Future<bool> restoreBackup(BuildContext context) async {
    try {
      // --- A. 选择文件 ---
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip'],
      );

      if (result == null || result.files.single.path == null) return false;

      final zipFile = File(result.files.single.path!);
      final appDocDir = await getApplicationDocumentsDirectory();

      // --- B. 解压 ---
      final tempDir = await getTemporaryDirectory();
      final extractDir = Directory('${tempDir.path}/monet_restore_work');
      if (extractDir.existsSync()) extractDir.deleteSync(recursive: true);
      extractDir.createSync();

      final bytes = await zipFile.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);

      for (final file in archive) {
        final filename = file.name;
        if (file.isFile) {
          final data = file.content as List<int>;
          File('${extractDir.path}/$filename')
            ..createSync(recursive: true)
            ..writeAsBytesSync(data);
        }
      }

      // --- C. 解析数据 ---
      final jsonFile = File('${extractDir.path}/data.json');
      if (!jsonFile.existsSync()) {
        throw Exception("无效的备份文件：缺少 data.json");
      }

      final String jsonStr = await jsonFile.readAsString();
      final Map<String, dynamic> fullData = jsonDecode(jsonStr);

      // --- D. 写入数据库 (事务) ---
      // 这是一个破坏性操作，建议先清空再写入，防止 ID 冲突
      await _isar.writeTxn(() async {
        // 1. 清空现有数据
        await _isar.books.clear();
        await _isar.chapters.clear();
        await _isar.dailyStats.clear();
        await _isar.promptTemplates.clear();

        // 2. 恢复图片资源 (从解压目录移动到 App 目录)
        Future<String?> restoreImage(String? fileName) async {
          if (fileName == null || fileName.isEmpty) return null;
          final sourceFile = File('${extractDir.path}/assets/$fileName');
          if (await sourceFile.exists()) {
            final targetPath = '${appDocDir.path}/$fileName';
            await sourceFile.copy(targetPath);
            return targetPath; // 返回新的绝对路径
          }
          return null;
        }

        // 3. 导入 Books (处理嵌套的图片路径)
        if (fullData['books'] != null) {
          final List<dynamic> booksList = fullData['books'];
          // 需要先把 JSON 转回 List<Map> 并修正路径
          for (var bookMap in booksList) {
            // 恢复封面路径
            if (bookMap['coverPath'] != null) {
              bookMap['coverPath'] = await restoreImage(bookMap['coverPath']);
            }

            // 恢复角色头像路径
            if (bookMap['characters'] != null) {
              for (var charMap in bookMap['characters']) {
                if (charMap['avatarPath'] != null) {
                  charMap['avatarPath'] = await restoreImage(charMap['avatarPath']);
                }
              }
            }
            if (bookMap['characterGroups'] != null) {
              for (var groupMap in bookMap['characterGroups']) {
                if (groupMap['characters'] != null) {
                  for (var charMap in groupMap['characters']) {
                    if (charMap['avatarPath'] != null) {
                      charMap['avatarPath'] = await restoreImage(charMap['avatarPath']);
                    }
                  }
                }
              }
            }
          }
          await _isar.books.importJson(booksList.cast<Map<String, dynamic>>());
        }

        // 4. 导入其他表
        if (fullData['chapters'] != null) {
          await _isar.chapters.importJson((fullData['chapters'] as List).cast<Map<String, dynamic>>());
        }
        if (fullData['daily_stats'] != null) {
          await _isar.dailyStats.importJson((fullData['daily_stats'] as List).cast<Map<String, dynamic>>());
        }
        if (fullData['prompts'] != null) {
          await _isar.promptTemplates.importJson((fullData['prompts'] as List).cast<Map<String, dynamic>>());
        }
      });

      return true;

    } catch (e) {
      debugPrint('Restore failed: $e');
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('恢复失败: $e')));
      }
      return false;
    }
  }
}
