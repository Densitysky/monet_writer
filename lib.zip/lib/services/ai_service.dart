
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:isar/isar.dart';
import 'package:monet_writer/models/ai_config.dart';
import 'package:monet_writer/services/database_service.dart';

class AiService {
  /// 1. 统一文本生成接口
  static Future<String> generateText(
      AiConfig config, {
        required String systemPrompt,
        required String userPrompt,
      }) async {
    if (config.apiKey.isEmpty) {
      throw Exception('请先在设置中配置 API Key');
    }

    final finalSystemPrompt = (config.customPrompt != null && config.customPrompt!.isNotEmpty)
        ? config.customPrompt!
        : systemPrompt;

    try {
      if (config.provider == 'google') {
        return await _callGemini(config, finalSystemPrompt, userPrompt);
      } else {
        return await _callOpenAICompatible(config, finalSystemPrompt, userPrompt);
      }
    } catch (e) {
      debugPrint('AI Request Failed: $e');
      throw Exception('AI 请求失败: $e');
    }
  }

  /// 2. 【新增】获取模型列表接口
  /// 支持 Google Gemini 和 OpenAI 格式的 /models 接口
  static Future<List<String>> fetchModels(AiConfig config) async {
    if (config.apiKey.isEmpty) throw Exception('API Key 不能为空');

    try {
      if (config.provider == 'google') {
        return await _fetchGeminiModels(config);
      } else {
        return await _fetchOpenAIModels(config);
      }
    } catch (e) {
      debugPrint('Fetch Models Failed: $e');
      throw Exception('获取模型列表失败: $e');
    }
  }

  // --- 内部实现 ---

  static Future<List<String>> _fetchGeminiModels(AiConfig config) async {
    final url = 'https://generativelanguage.googleapis.com/v1beta/models?key=${config.apiKey}';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List<dynamic> models = data['models'] ?? [];
      // Google 返回的 name 格式为 "models/gemini-pro"，我们需要去掉前缀
      return models
          .map((m) => m['name'].toString().replaceFirst('models/', ''))
          .toList();
    } else {
      throw Exception('Google API Error: ${response.body}');
    }
  }

  static Future<List<String>> _fetchOpenAIModels(AiConfig config) async {
    final baseUrl = config.baseUrl.isEmpty ? 'https://api.openai.com/v1' : config.baseUrl;
    final cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    // 适配部分厂商的 models 路径（有些是 /v1/models，有些直接是 /models，这里默认走标准 /v1/models）
    // 如果 base url 已经包含了 v1，则不重复添加
    final url = cleanBaseUrl.endsWith('v1') ? '$cleanBaseUrl/models' : '$cleanBaseUrl/v1/models';

    final response = await http.get(
      Uri.parse(url),
      headers: {'Authorization': 'Bearer ${config.apiKey}'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final List<dynamic> list = data['data'] ?? [];
      return list.map((m) => m['id'].toString()).toList();
    } else {
      throw Exception('API Error (${response.statusCode}): ${response.body}');
    }
  }

  static Future<String> _callGemini(AiConfig config, String sys, String user) async {
    final model = config.modelName.isEmpty ? 'gemini-pro' : config.modelName;
    final url = 'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${config.apiKey}';

    final response = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        "contents": [{"parts": [{"text": "$sys\n\n$user"}]}]
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['candidates'] == null || (data['candidates'] as List).isEmpty) {
        return "AI 没有返回任何内容 (可能是安全拦截)";
      }
      return data['candidates'][0]['content']['parts'][0]['text'];
    } else {
      throw Exception('Gemini Error: ${response.body}');
    }
  }

  static Future<String> _callOpenAICompatible(AiConfig config, String sys, String user) async {
    final baseUrl = config.baseUrl.isEmpty ? 'https://api.openai.com/v1' : config.baseUrl;
    final cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    final url = '$cleanBaseUrl/chat/completions';

    final response = await http.post(
      Uri.parse(url),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${config.apiKey}',
      },
      body: jsonEncode({
        "model": config.modelName,
        "messages": [
          {"role": "system", "content": sys},
          {"role": "user", "content": user}
        ],
        "temperature": 0.7,
      }),
    );

    if (response.statusCode == 200) {
      final bodyBytes = response.bodyBytes;
      final bodyString = utf8.decode(bodyBytes);
      final data = jsonDecode(bodyString);
      return data['choices'][0]['message']['content'];
    } else {
      throw Exception('API Error (${response.statusCode}): ${response.body}');
    }
  }
}

class AiProvider extends ChangeNotifier {
  AiConfig _config = AiConfig();
  AiConfig get config => _config;

  // 【新增】可用模型列表
  List<String> _availableModels = [];
  List<String> get availableModels => _availableModels;

  final Isar _isar = DatabaseService().isar;

  Future<void> loadConfig() async {
    final c = await _isar.aiConfigs.where().findFirst();
    if (c != null) {
      _config = c;
    } else {
      _config = AiConfig()..provider = 'google'..modelName = 'gemini-pro';
      await _isar.writeTxn(() async => await _isar.aiConfigs.put(_config));
    }
    notifyListeners();
  }

  Future<void> updateConfig(AiConfig newConfig) async {
    newConfig.id = _config.id;
    await _isar.writeTxn(() async {
      await _isar.aiConfigs.put(newConfig);
    });
    _config = newConfig;
    notifyListeners();
  }

  // 【新增】更新内存中的模型列表 (不存库)
  void setAvailableModels(List<String> models) {
    _availableModels = models;
    notifyListeners();
  }
}
